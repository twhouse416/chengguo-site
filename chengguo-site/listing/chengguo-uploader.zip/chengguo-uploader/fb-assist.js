// 在 Facebook「你的商品」頁協助：更新刊登（自動按「更新」）或重新上架（提醒先刪除舊刊登）
function cgAssist(kind, title, id, caseNo) {
  const norm = s => String(s || '').replace(/\s+/g, '').slice(0, 18);
  const key = norm(title);
  const old = document.getElementById('cg-assist'); if (old) old.remove();
  const bar = document.createElement('div'); bar.id = 'cg-assist';
  bar.style.cssText = 'position:fixed;left:50%;top:70px;transform:translateX(-50%);z-index:2147483647;max-width:560px;width:calc(100% - 24px);padding:14px 16px;font:15px/1.6 sans-serif;color:#151513;background:#fff;border:3px solid #FD7305;border-radius:6px;box-shadow:0 6px 24px rgba(0,0,0,.25)';
  const p = document.createElement('div'); bar.appendChild(p);
  const say = t => { p.textContent = t; };
  document.body.appendChild(bar);

  // 找到這筆刊登所在的卡片
  const findCard = () => {
    const hits = [...document.querySelectorAll('span,div,a')].filter(e => e.children.length === 0 && key && norm(e.textContent).includes(key.slice(0, 12)));
    for (const h of hits) {
      let c = h;
      for (let i = 0; i < 8 && c; i++) { c = c.parentElement; if (c && c.querySelectorAll('[role=button],button').length >= 2) return c; }
    }
    return null;
  };

  const run = async () => {
    say(`澄果上架：正在「你的商品」裡尋找「${title}」…`);
    let card = null;
    for (let i = 0; i < 20 && !card; i++) { card = findCard(); if (!card) await new Promise(r => setTimeout(r, 500)); }
    if (kind === 'renew') {
      if (!card) { say(`澄果上架：在「你的商品」裡找不到「${title}」。可能已刪除或標示售出；若還在架上，請手動找到它按「更新」。`); return; }
      card.scrollIntoView({ block: 'center' });
      card.style.outline = '4px solid #FD7305';
      const btn = [...card.querySelectorAll('[role=button],button,a')].find(b => /^(更新|續刊|重新刊登|更新刊登|Renew)/.test((b.innerText || b.getAttribute('aria-label') || '').trim()));
      if (btn) { btn.click(); say(`✔ 澄果上架：已幫「${title}」按下「更新」。請看一下畫面確認成功。`); chrome.runtime.sendMessage({ type: 'log', what: '更新', title, caseNo }); }
      else say(`澄果上架：找到「${title}」，但目前沒有「更新」按鈕（Facebook 通常要刊登滿 7 天才開放更新）。這次先不用處理，之後會再照排程提醒重新上架。`);
      return;
    }
    // relist：提醒先刪舊刊登，刪完再按按鈕
    if (card) { card.scrollIntoView({ block: 'center' }); card.style.outline = '4px solid #FD7305'; }
    say(card
      ? `澄果上架：要重新上架「${title}」。請先刪除橘框這筆舊刊登（按它的「⋯」或「管理」→「刪除刊登」），刪除後再按下面的按鈕。`
      : `澄果上架：要重新上架「${title}」。在「你的商品」裡沒找到舊刊登（可能已刪除）。確認沒有舊刊登後，按下面的按鈕。`);
    const go = document.createElement('button');
    go.textContent = '我已刪除舊刊登，開始重新上架';
    go.style.cssText = 'margin-top:10px;min-height:44px;padding:8px 18px;border:0;border-radius:4px;background:#FD7305;color:#fff;font:700 15px sans-serif;cursor:pointer';
    const no = document.createElement('button');
    no.textContent = '這筆已成交，停止排程';
    no.style.cssText = 'margin:10px 0 0 10px;min-height:44px;padding:8px 14px;border:1px solid #dcdcd6;border-radius:4px;background:#fff;font:15px sans-serif;cursor:pointer';
    go.onclick = async () => { go.disabled = true; say('澄果上架：正在開啟重新上架視窗…'); const r = await chrome.runtime.sendMessage({ type: 'relist', id }); if (r && r.error) { say('澄果上架：' + r.error); go.disabled = false; return; } bar.remove(); };
    no.onclick = async () => { await chrome.runtime.sendMessage({ type: 'cancelSched', id }); chrome.runtime.sendMessage({ type: 'log', what: '停止排程（已成交）', title, caseNo }); say(`澄果上架：已停止「${title}」的排程。記得把舊刊登標示為已售出或刪除。`); go.remove(); no.remove(); };
    bar.append(go, no);
  };
  run();
}

// 全自動用：在「你的商品」刪除標題相符且唯一的那一筆刊登。回傳 {ok, reason}
async function cgAutoDelete(title) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').replace(/\s+/g, '').replace(/[…\.]+$/, '');
  const key = norm(title).slice(0, 14);
  const txt = e => (e.innerText || e.getAttribute('aria-label') || '').trim();
  const cards = () => {
    const hits = [...document.querySelectorAll('span,div,a')].filter(e => e.children.length === 0 && key && norm(e.textContent).startsWith(key));
    const out = new Set();
    for (const h of hits) { let c = h; for (let i = 0; i < 8 && c; i++) { c = c.parentElement; if (c && c.querySelectorAll('[role=button],button').length >= 2) { out.add(c); break; } } }
    // 只保留最外層、互不包含的卡片
    return [...out].filter(c => ![...out].some(o => o !== c && o.contains(c)));
  };
  const waitFor = async (fn, ms) => { const end = Date.now() + ms; while (Date.now() < end) { const v = fn(); if (v) return v; await sleep(300); } return null; };
  let list = [];
  for (let i = 0; i < 30; i++) { list = cards(); if (list.length) break; await sleep(500); }
  if (list.length === 0) return { ok: false, reason: 'not-found' };
  if (list.length > 1) return { ok: false, reason: 'multiple' };
  const card = list[0];
  card.scrollIntoView({ block: 'center' }); card.style.outline = '4px solid #b42318';
  const more = [...card.querySelectorAll('[role=button],button')].find(b => /更多|選項|管理|More|⋯|…|\.\.\./.test(txt(b)));
  if (!more) return { ok: false, reason: 'no-menu' };
  more.click();
  const del = await waitFor(() => [...document.querySelectorAll('[role=menuitem],[role=menu] [role=button],[role=dialog] [role=button],[role=menu] div,[role=dialog] div')].find(e => e.children.length <= 3 && /^(刪除刊登|刪除商品|刪除|Delete listing|Delete)$/.test(txt(e))), 6000);
  if (!del) { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); return { ok: false, reason: 'no-delete-item' }; }
  (del.closest('[role=menuitem],[role=button]') || del).click();
  const ok = await waitFor(() => [...document.querySelectorAll('[role=dialog] [role=button],[role=dialog] button')].find(b => /^(刪除|確認|Delete)$/.test(txt(b))), 6000);
  if (ok) ok.click();
  await sleep(3000);
  return cards().length === 0 ? { ok: true } : { ok: false, reason: 'still-there' };
}
