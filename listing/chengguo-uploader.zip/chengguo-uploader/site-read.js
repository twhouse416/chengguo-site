// 從台灣房屋官網物件頁讀出公開資料（在物件頁裡執行）。只讀畫面上給客人看的內容，不讀業務聯絡資訊。
function readTwhgListing(text, title, url) {
  const L = String(text).split('\n').map(s => s.trim()).filter(Boolean);
  const after = (label, from = 0) => { for (let i = from; i < L.length - 1; i++) if (L[i] === label) return L[i + 1]; return ''; };
  const num = s => (String(s).replace(/,/g, '').match(/\d+(?:\.\d+)?/) || [''])[0];
  const d = L.indexOf('詳細資料');
  const D = d >= 0 ? d : 0;
  const o = {};
  o.caseNo = (String(url).match(/buy\/([A-Z]{2}\d+)/i) || [])[1] || ((L.find(x => /\([A-Z]{2}\d{6,}\)/.test(x)) || '').match(/\(([A-Z]{2}\d+)\)/) || [])[1] || '';
  o.title = String(title || '').split('｜')[0].trim();
  const pi = L.findIndex((x, i) => /^[\d,]+(\.\d+)?$/.test(x) && L[i + 1] === '萬');
  o.price = pi >= 0 ? num(L[pi]) : '';
  const addr = after('地址').replace(/\s*查看地圖.*$/, '');
  const dm = addr.match(/(?:市|縣)(.{1,3}?[區鄉鎮市])/); o.district = dm ? dm[1] : '';
  const rest = addr.replace(/^(?:.{2,3}[市縣])?.{1,3}?[區鄉鎮市]/, '');
  const rm = rest.match(/^(.*?(?:路|街|大道)(?:[一二三四五六七八九十]段)?)/); o.road = rm ? rm[1] : rest.replace(/\d.*$/, '');
  o.type = after('類型', D);
  o.layout = after('格局', D);
  o.age = num(after('屋齡', D));
  o.facing = after('座向', D);
  o.material = after('建材', D);
  o.parking = after('車位', D).replace(/\s*車位管理費.*$/, '');
  o.fee = after('管理費', D).replace(/\(.*?\)/g, '').trim();
  o.community = after('社區', D);
  o.areaTotal = after('建坪', D).replace(/\s+/g, ' ');
  o.areaMain = num(after('*主建物', D));
  o.areaMainBalcony = num(after('*主+陽', D));
  o.areaLand = num(after('土地坪數', D));
  const fi = L.indexOf('吸睛特色');
  o.tags = [];
  if (fi >= 0) for (let i = fi + 1; i < L.length; i++) { const x = L[i]; if (/^(預約看屋|聯絡時間|地圖周邊|地圖週邊|實價登錄)/.test(x) || x.length > 14) break; o.tags.push(x); }
  for (const k of Object.keys(o)) if (o[k] === '-' || o[k] === '- 坪') o[k] = '';
  return o;
}

// 從官網物件頁找出這筆物件的照片網址（依頁面順序）。
// 排除網站橫幅、Logo、推薦物件等；同一資料夾照片最多的那一組視為本物件相簿。
function readTwhgPhotos(caseNo) {
  const urls = [];
  const add = u => {
    if (!u) return;
    u = String(u).trim().replace(/^url\(["']?|["']?\)$/g, '').replace(/\\\//g, '/').replace(/&amp;/g, '&');
    if (u.startsWith('//')) u = 'https:' + u;
    if (!/^https?:/i.test(u)) { try { u = new URL(u, location.href).href; } catch (e) { return; } }
    if (!/\.(jpe?g|png|webp)(\?|$)/i.test(u)) return;
    if (/logo|icon|favicon|facebook|line\.me|google|\/storage\/image\/(selector|brand|topic|banner|ad)\/|\/resource\/(logo|footer)|avatar|qrcode|staticmap|sprite/i.test(u)) return;
    urls.push(u);
  };
  document.querySelectorAll('img,source').forEach(i => {
    ['data-src', 'data-original', 'data-lazy', 'data-zoom-image', 'src'].forEach(a => add(i.getAttribute(a)));
    (i.getAttribute('srcset') || i.getAttribute('data-srcset') || '').split(',').forEach(s => add(s.trim().split(/\s+/)[0]));
  });
  document.querySelectorAll('[style*="url("]').forEach(e => (e.getAttribute('style').match(/url\([^)]+\)/g) || []).forEach(add));
  document.querySelectorAll('a[href]').forEach(a => add(a.getAttribute('href')));
  (document.documentElement.innerHTML.match(/https?:(?:\\?\/){2}[^"'\s<>()]+?\.(?:jpe?g|png|webp)(?:\?[^"'\s<>()]*)?/gi) || []).forEach(add);
  // 去重（同一張不同尺寸視為同一張）
  const stem = u => u.split('?')[0].split('/').pop().replace(/([_-](s|m|l|xs|sm|md|lg|xl|thumb|small|big|large|\d+x\d+|w\d+))+(?=\.\w+$)/i, '').toLowerCase();
  const size = u => { const m = u.split('?')[0].match(/[_-](xl|large|big|l|lg|m|md|s|sm|small|xs|thumb)(?=\.\w+$)/i); return m ? ({ xl: 5, large: 4, big: 4, l: 4, lg: 4, m: 2, md: 2, s: 1, sm: 1, small: 1, xs: 0, thumb: 0 })[m[1].toLowerCase()] : 3; };
  const pos = new Map(), list = [];
  for (const u of urls) { const k = stem(u); if (!pos.has(k)) { pos.set(k, list.length); list.push(u); } else if (size(u) > size(list[pos.get(k)])) list[pos.get(k)] = u; }
  if (!list.length) return [];
  // 網址含物件編號的優先
  if (caseNo) { const own = list.filter(u => u.toUpperCase().includes(caseNo.toUpperCase())); if (own.length >= 2) return own; }
  // 依資料夾分組，取張數最多的一組（相簿照片通常放同一個資料夾）
  const dir = u => u.split('?')[0].replace(/\/[^/]*$/, '');
  const groups = {};
  list.forEach(u => (groups[dir(u)] = groups[dir(u)] || []).push(u));
  const best = Object.values(groups).sort((a, b) => b.length - a.length)[0];
  return best.length >= 2 ? best : list;
}
