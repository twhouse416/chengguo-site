// 屋主銷售週報：近 7 天的刊登、詢問、帶看，加上同社區實價，產生 LINE 文字版與圖片／PDF
const $ = id => document.getElementById(id);
const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const md = t => { const d = new Date(t); return `${d.getMonth() + 1}/${d.getDate()}`; };
const caseNo = new URLSearchParams(location.search).get('case') || '';
let D = null;

function weekly(item) {
  const since = Date.now() - 7 * 864e5, src = {};
  let inq = 0, visit = 0;
  for (const [t, k, s] of (item.acts || [])) { if (t < since) continue; if (k === 'visit') visit++; else { inq++; src[s] = (src[s] || 0) + 1; } }
  return { inq, visit, src };
}
function defaultPlan(item, w, days) {
  const lines = [];
  if (!item.fb || !item.rakuya || !item.f591) lines.push('・補上尚未刊登的平台，擴大曝光。');
  lines.push('・持續更新 FB 刊登，並主動推薦給條件相符的買方客戶。');
  if (days >= 30 && !w.visit) lines.push('・本週沒有帶看，想跟您約時間討論目前的價格與市場反應。');
  else if (w.visit) lines.push('・追蹤本週帶看客戶的意見，有進展會第一時間回報。');
  return lines.join('\n');
}
function build() {
  const { item, site, market, profile } = D;
  const w = weekly(item), days = item.firstAt ? Math.floor((Date.now() - item.firstAt) / 864e5) : null;
  const price = item.curPrice || (site && site.price) || item.price || '';
  const title = (site && site.title) || item.title || item.caseNo;
  const range = `${md(Date.now() - 6 * 864e5)}–${md(Date.now())}`;
  const plat = [['Facebook', item.fb], ['樂屋網', item.rakuya], ['591', item.f591]];
  const srcTxt = Object.entries(w.src).map(([k, v]) => `${k} ${v}`).join('、');
  const plan = $('plan').value.trim();
  const mc = market && market.community, ma = market && market.area;

  // ---- 圖片／PDF 版 ----
  const kp = `<div class="kp">
<div class="hot"><b>${w.inq}</b><span>本週詢問${srcTxt ? `（${esc(srcTxt)}）` : ''}</span></div>
<div class="hot"><b>${w.visit}</b><span>本週帶看</span></div>
<div><b>${item.inq || 0}</b><span>累計詢問</span></div>
<div><b>${item.visit || 0}</b><span>累計帶看</span></div></div>`;
  const pl = `<div class="plat">${plat.map(([n, t]) => `<div class="${t ? 'y' : ''}"><b>${n}</b><span>${t ? `${md(t)} 起刊登・${Math.floor((Date.now() - t) / 864e5)} 天` : '尚未刊登'}</span></div>`).join('')}</div>`;
  let mk = '';
  if (mc && mc.count) {
    mk = `<p style="margin:0 0 8px">「${esc(mc.name)}」近三年成交 <b>${mc.count}</b> 筆，單價 <b>${mc.min}～${mc.max}</b> 萬／坪，中位數 <b>${mc.median}</b> 萬／坪。</p>
<table class="deals"><tr><th>成交日期</th><th>樓層</th><th>坪數</th><th>單價（萬／坪）</th><th>總價（萬）</th></tr>
${mc.recent.slice(0, 4).map(d => `<tr><td>${esc(d[0])}</td><td>${esc(d[5])}</td><td>${esc(d[3])}</td><td>${esc(d[1])}</td><td>${esc(d[2])}</td></tr>`).join('')}</table>`;
  } else if (mc) mk = `<p style="margin:0">「${esc(mc.name)}」近三年沒有住家成交紀錄。</p>`;
  if (ma) mk += `<p style="margin:8px 0 0">${esc(ma.name)}${esc(ma.label)}近一年單價中位數 <b>${ma.med}</b> 萬／坪（常見區間 ${ma.lo}～${ma.hi} 萬，${ma.n} 筆）。</p>`;
  if (mk) mk += `<p class="src">資料來源：${esc(market.source)}；僅供參考，實際以產權與交易條件為準。</p>`;
  $('card').innerHTML = `
<div class="c-hd"><p class="en">WEEKLY REPORT・${range}</p><h2>${esc(title)}</h2><p class="sub">物件編號 ${esc(item.caseNo)}${days != null ? `｜掛牌第 ${days} 天` : ''}</p>
${price ? `<div class="price"><b>${esc(price)} 萬</b><span>目前開價</span></div>` : ''}</div>
<div class="c-bd">
<div class="sec"><h3>本週成果</h3>${kp}</div>
<div class="sec"><h3>刊登平台</h3>${pl}</div>
${mk ? `<div class="sec"><h3>同社區行情（實價登錄）</h3>${mk}</div>` : ''}
${plan ? `<div class="sec"><h3>下週計畫</h3><div class="plan">${esc(plan)}</div></div>` : ''}
</div>
<div class="c-ft"><span>台灣房屋 澄果團隊｜美術青海特許加盟店</span><span><b>${esc(profile.name)}</b>　${esc(profile.phone || '')}${profile.line ? `　LINE ${esc(profile.line)}` : ''}</span></div>`;

  // ---- LINE 文字版 ----
  const t = [];
  t.push(`【物件銷售週報】${range}`);
  t.push(`物件：${title}（${item.caseNo}）`);
  if (price) t.push(`目前開價：${price} 萬`);
  if (days != null) t.push(`掛牌第 ${days} 天`);
  t.push('━━━━━━━━━━');
  t.push('▍本週成果');
  t.push(`・詢問 ${w.inq} 組${srcTxt ? `（${srcTxt}）` : ''}`);
  t.push(`・帶看 ${w.visit} 組`);
  t.push(`・累計：詢問 ${item.inq || 0} 組、帶看 ${item.visit || 0} 組`);
  t.push('▍刊登平台');
  for (const [n, d] of plat) t.push(`・${n}：${d ? `${md(d)} 起刊登` : '尚未刊登'}`);
  if (mc && mc.count) {
    t.push('▍同社區行情（近三年實價登錄）');
    t.push(`・「${mc.name}」成交 ${mc.count} 筆，單價 ${mc.min}～${mc.max} 萬／坪，中位數 ${mc.median} 萬`);
    for (const d of mc.recent.slice(0, 3)) t.push(`・${d[0]}　${d[5]}　${d[3]} 坪　${d[1]} 萬／坪（總價 ${d[2]} 萬）`);
  }
  if (ma) t.push(`・${ma.name}${ma.label}近一年中位數 ${ma.med} 萬／坪`);
  if (plan) { t.push('▍下週計畫'); t.push(plan); }
  t.push('━━━━━━━━━━');
  t.push(`台灣房屋澄果團隊　${profile.name}${profile.phone ? '　' + profile.phone : ''}`);
  $('txt').textContent = t.join('\n');
}

async function init() {
  if (!caseNo) { $('state').textContent = '缺少物件編號，請從「我的刊登」按「屋主週報」開啟。'; return; }
  const r = await chrome.runtime.sendMessage({ type: 'reportData', caseNo });
  if (!r || !r.ok) { $('state').className = 'hint err'; $('state').textContent = (r && r.error) || '讀取失敗，請稍後再試。'; return; }
  D = r;
  const w = weekly(r.item), days = r.item.firstAt ? Math.floor((Date.now() - r.item.firstAt) / 864e5) : 0;
  $('plan').value = defaultPlan(r.item, w, days);
  $('state').hidden = true; $('card').hidden = false; $('txtBox').hidden = false;
  build();
  if (!r.site) $('msg').textContent = '讀不到官網資料，週報沒有附上實價。';
}
$('plan').addEventListener('input', () => D && build());
$('copyTxt').onclick = async () => {
  try { await navigator.clipboard.writeText($('txt').textContent); $('msg').className = 'hint ok'; $('msg').textContent = '已複製，貼到 LINE 傳給屋主即可。'; chrome.runtime.sendMessage({ type: 'log', what: '屋主週報', title: D.item.title, caseNo: D.item.caseNo, note: '文字版' }); }
  catch (e) { $('msg').className = 'hint err'; $('msg').textContent = '複製失敗，請展開下方預覽自己選取複製。'; }
};
$('saveImg').onclick = async () => {
  $('saveImg').disabled = true; $('msg').className = 'hint'; $('msg').textContent = '產生圖片中…';
  try {
    const cv = await html2canvas($('card'), { scale: 2, backgroundColor: '#ffffff', useCORS: true });
    const a = document.createElement('a'); a.download = `屋主週報_${D.item.caseNo}_${new Date().toISOString().slice(0, 10)}.png`; a.href = cv.toDataURL('image/png'); a.click();
    $('msg').className = 'hint ok'; $('msg').textContent = '圖片已下載，可以直接傳 LINE。';
    chrome.runtime.sendMessage({ type: 'log', what: '屋主週報', title: D.item.title, caseNo: D.item.caseNo, note: '圖片' });
  } catch (e) { $('msg').className = 'hint err'; $('msg').textContent = '產生圖片失敗：' + (e.message || e); }
  $('saveImg').disabled = false;
};
$('printPdf').onclick = () => window.print();
init();
