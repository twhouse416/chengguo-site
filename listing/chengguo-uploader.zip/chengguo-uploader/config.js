// 管理者設定：Google 試算表「部署為網頁應用程式」後的網址，與試算表程式裡的 TOKEN 必須相同
const CG_API_URL = 'https://script.google.com/macros/s/AKfycbyU7eB6dXEm-fv-faA7trOK9kGjpqA7aXy-IjNYlMpVKk1LXp-8nJ6GTfATX57rdVGX/exec';
const CG_TOKEN = 'cg_mXXrU7qcFjQaS-xUzTLGlUiG3Dq5WqYR';
