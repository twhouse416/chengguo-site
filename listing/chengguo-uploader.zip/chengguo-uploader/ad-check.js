// 廣告用語檢查：找出容易被認定為不實或誇大廣告的字眼（只提醒，不會自動修改）
// 確認頁、樂屋網、591 填好後都會用這一份清單。要增減字眼，改下面 CG_AD_RULES 即可。
const CG_AD_RULES = [
  { why: '保證未來增值或獲利', words: ['保證增值', '包增值', '必漲', '穩漲', '穩賺', '穩賺不賠', '保證獲利', '保證賺', '保證投報', '保證報酬', '零風險', '包租'] },
  { why: '價格比較要有依據', words: ['低於行情', '低於市價', '低於實價', '全區最低', '全社區最低', '最低價', '最便宜', '破盤價', '跳樓價', '賠售', '殺很大'] },
  { why: '貸款條件不能保證', words: ['保證貸款', '貸款保證', '保證核貸', '成數保證', '免頭期', '零頭期', '免自備款', '零自備'] },
  { why: '誇大的最高級用語', words: ['全台最', '全國最', '全高雄最', '高雄第一', '第一品牌', '絕無僅有'] }
];
function cgAdRisk(text) {
  const t = String(text || '').replace(/\s+/g, '');
  const hits = [];
  for (const r of CG_AD_RULES) for (const w of r.words) if (t.includes(w) && !hits.some(h => h.word.includes(w))) hits.push({ word: w, why: r.why });
  return hits.filter(h => !hits.some(o => o !== h && o.word.includes(h.word)));
}
// 在樂屋網／591 頁面執行：讀說明欄文字，把結果加到「澄果上架」提示條
function cgAdBanner() {
  let text = '';
  try { if (window.jQuery && jQuery('#remark').length) text = jQuery('<div>').html(jQuery('#remark').summernote('code')).text(); } catch (e) {}
  if (!text) { const ed = document.querySelector('.ProseMirror') || document.querySelector('#remark'); text = ed ? (ed.innerText || ed.value || '') : ''; }
  const title = (document.querySelector('input[name=header]') || document.querySelector('[name=hname]') || {}).value || '';
  const hits = cgAdRisk(title + '\n' + text);
  if (!hits.length) return 0;
  const b = document.getElementById('cg-banner');
  const p = document.createElement('div');
  p.style.cssText = 'background:#fff6cc;color:#151513;border-radius:3px;padding:2px 8px;margin-top:4px';
  p.textContent = '⚠ 廣告用語提醒：' + hits.map(h => `「${h.word}」（${h.why}）`).join('、') + '。容易被認定為不實或誇大廣告，建議修改。';
  if (b) b.insertBefore(p, b.querySelector('button'));
  return hits.length;
}
