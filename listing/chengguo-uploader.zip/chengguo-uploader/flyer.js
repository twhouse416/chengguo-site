// 帶看物件介紹單：A4（列印／PDF）或手機長圖（PNG），同仁自己選
const $ = id => document.getElementById(id);
const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let D = null;
const fmt = () => (document.querySelector('input[name=fmt]:checked') || {}).value || 'a4';

function defaultFeat(site, ai) {
  let t = ai && ai.body ? ai.body : (site.feature || '');
  t = t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  const lines = t.split('\n').filter(l => l.trim());
  return lines.slice(0, 10).join('\n');
}
function build() {
  const { site: s, photos, market, profile: p } = D;
  const f = fmt();
  const el = $('flyer'); el.className = 'flyer ' + f;
  const spec = [['總價', s.price ? s.price + ' 萬' : ''], ['格局', s.layout], ['建坪', s.areaTotal], ['主建物', s.areaMain ? s.areaMain + ' 坪' : ''], ['屋齡', s.age ? s.age + ' 年' : ''], ['樓層', s.floor], ['車位', s.parking], ['管理費', s.fee]]
    .filter(([, v]) => v && v !== '-');
  const feat = $('feat').value.trim();
  const featShown = f === 'a4' ? feat.split('\n').slice(0, 9).join('\n') : feat;
  const more = photos.slice(1, f === 'a4' ? 4 : 7);
  const mc = market && market.community;
  const loc = ['高雄市' + (s.district || ''), s.road, s.community && `社區：${s.community}`].filter(Boolean).join('　');
  const contact = [p.phone, p.line && `LINE ${p.line}`].filter(Boolean).join('｜');
  el.innerHTML = `
<div class="f-top"><span>台灣房屋 澄果團隊｜美術青海特許加盟店</span><b>PROPERTY</b></div>
${photos[0] ? `<div class="f-hero"><img src="${photos[0]}" alt="">${s.price ? `<div class="f-price"><b>${esc(s.price)} 萬</b><span>開價</span></div>` : ''}</div>` : ''}
<div class="f-main">
<h2>${esc(s.title)}</h2>
<p class="f-loc">${esc(loc)}</p>
<div class="f-spec">${spec.map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}</div>
${(s.tags || []).length ? `<div class="f-tags">${s.tags.slice(0, 8).map(t => `<span>${esc(t)}</span>`).join('')}</div>` : ''}
${featShown ? `<div class="f-feat">${esc(featShown)}</div>` : ''}
</div>
${more.length ? `<div class="f-photos">${more.map(u => `<img src="${u}" alt="">`).join('')}</div>` : ''}
${mc && mc.count ? `<div class="f-mk">同社區「${esc(mc.name)}」近三年實價登錄 ${mc.count} 筆，單價 <b>${mc.min}～${mc.max}</b> 萬／坪，中位數 <b>${mc.median}</b> 萬／坪。<span style="color:#64748B">（資料來源：${esc(market.source)}，僅供參考）</span></div>` : ''}
<div class="f-ft"><div class="who"><b>${esc(p.name)}</b><span>${esc(contact)}</span>${p.lic ? `<span style="display:block;font-size:12px">營業員證號 ${esc(p.lic)}</span>` : ''}</div>
<div class="co">經紀業：澄果資產有限公司<br>經紀人：邱秀琴(109)屏縣字第000147<br>高雄市鼓山區青海路416號｜07-9766977<br>物件資訊以現況及產權登記資料為準</div></div>`;
  $('go').textContent = f === 'a4' ? '列印／存成 PDF' : '下載長圖（PNG）';
}

async function init() {
  const { flyerFmt } = await chrome.storage.local.get('flyerFmt');
  const q = new URLSearchParams(location.search).get('fmt');
  const f0 = q || flyerFmt || 'a4';
  document.querySelector(`input[name=fmt][value=${f0 === 'long' ? 'long' : 'a4'}]`).checked = true;
  const r = await chrome.runtime.sendMessage({ type: 'flyerData' });
  if (!r || !r.ok) { $('state').className = 'hint err'; $('state').textContent = (r && r.error) || '讀取失敗。'; return; }
  D = r;
  $('feat').value = defaultFeat(r.site, r.ai);
  $('state').hidden = true; $('flyer').hidden = false;
  build();
  if (!r.photos.length) $('msg').textContent = '沒有可用的照片，介紹單會沒有圖片。';
}
document.querySelectorAll('input[name=fmt]').forEach(x => x.onchange = () => { chrome.storage.local.set({ flyerFmt: fmt() }); D && build(); });
$('feat').addEventListener('input', () => D && build());
$('go').onclick = async () => {
  if (fmt() === 'a4') { window.print(); chrome.runtime.sendMessage({ type: 'log', what: '帶看介紹單', title: D.site.title, caseNo: D.site.caseNo, note: 'A4' }); return; }
  $('go').disabled = true; $('msg').className = 'hint'; $('msg').textContent = '產生長圖中…';
  try {
    const cv = await html2canvas($('flyer'), { scale: 1.5, backgroundColor: '#ffffff' });
    const a = document.createElement('a'); a.download = `物件介紹_${D.site.caseNo || ''}.png`; a.href = cv.toDataURL('image/png'); a.click();
    $('msg').className = 'hint ok'; $('msg').textContent = '長圖已下載，可以直接傳 LINE 給客戶。';
    chrome.runtime.sendMessage({ type: 'log', what: '帶看介紹單', title: D.site.title, caseNo: D.site.caseNo, note: '長圖' });
  } catch (e) { $('msg').className = 'hint err'; $('msg').textContent = '產生失敗：' + (e.message || e); }
  $('go').disabled = false;
};
init();
