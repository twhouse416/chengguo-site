importScripts('config.js', 'desc.js', 'rakuya-fill.js', 'f591-fill.js');
// 澄果上架：開一個手機模式視窗，打開 Marketplace 手機版刊登頁，自動填入上架包內容。
// 不會按「發佈」——發布一律由同仁自己確認後按下。

const FORM_URL = 'https://m.facebook.com/marketplace/selling/item/';
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
const attached = new Set();

// ===== 名單驗證與使用紀錄（Google 試算表） =====
async function api(body) {
  if (!/^https:\/\/script\.google\.com\//.test(CG_API_URL)) throw new Error('擴充功能尚未設定名單網址，請洽管理者。');
  const r = await fetch(CG_API_URL, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ token: CG_TOKEN, ...body }), redirect: 'follow' });
  return r.json();
}
async function myEmail() {
  const u = await chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' });
  return (u && u.email) || '';
}
async function whoami() {
  const email = await myEmail();
  if (!email) throw new Error('請先在 Chrome 右上角登入你的 Google 帳號，才能使用澄果上架。');
  let r;
  try { r = await api({ action: 'check', email }); } catch (e) { throw new Error(e.message.includes('名單網址') ? e.message : '連不到名單，請確認網路連線後再試。'); }
  if (!r || !r.ok) throw new Error(r && r.error === 'disabled' ? `此帳號（${email}）尚未啟用或已停用。剛登記的話，請等管理者審核啟用。` : `此帳號（${email}）還沒登記。請到 k7.com.tw/listing/join.html 登記，管理者啟用後就能使用。`);
  return { email, name: r.name, phone: r.phone, line: r.line, lic: r.lic };
}
async function log(what, title, caseNo, note) {
  try { const email = await myEmail(); if (email) await api({ action: 'log', email, what, title: title || '', caseNo: caseNo || '', note: note || '' }); } catch (e) {}
}
function footerOf(p) {
  const contact = [p.name && `聯絡人：${p.name}`, p.phone && `電話：${p.phone}`, p.line && `LINE：${p.line}`, p.lic && `營業員證號：${p.lic}`].filter(Boolean).join('｜');
  return ['', '——————', '台灣房屋 澄果團隊（澄果資產有限公司）', contact, '店址：高雄市鼓山區青海路416號｜店電：07-9766977', '物件資訊以現況及產權登記資料為準', '經紀人：邱秀琴(109)屏縣字第000147號'].filter((x, i) => i === 0 || x).join('\n');
}
// 依名單上的資料重寫結尾，避免冒用別人名義
function withFooter(desc, p) {
  const i = String(desc || '').indexOf('\n——————');
  return (i >= 0 ? desc.slice(0, i) : String(desc || '')).replace(/\s+$/, '') + '\n' + footerOf(p);
}
const tabJob = {};  // 填寫視窗 tabId → 物件（供「已發佈」紀錄）


chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m && m.type === 'whoami') {
    whoami().then(p => reply({ ok: true, profile: p }), err => reply({ error: err.message }));
    return true;
  }
  if (m && m.type === 'start') {
    (async () => {
      const p = await whoami();
      const { job } = await chrome.storage.local.get('job');
      if (!job) throw new Error('找不到要上架的資料，請重新操作。');
      job.description = withFooter(job.description, p);
      await chrome.storage.local.set({ job });
      if (m.schedule) await addSchedule(m.schedule);
      reply({ ok: true });
      log('上架', job.title, job.caseNo);
      await start();
    })().catch(err => { try { reply({ error: err.message }); } catch (e) {} console.error('[澄果上架]', err); });
    return true;
  }
  if (m && m.type === 'relist') {
    (async () => { await whoami(); reply({ ok: true }); await relist(m.id); })().catch(err => { try { reply({ error: err.message }); } catch (e) {} });
    return true;
  }
  if (m && m.type === 'takedown') {
    reply({ ok: true });
    getSched().then(l => { const e = l.find(x => x.id === m.id); if (e) takedown(e); });
    return false;
  }
  if (m && m.type === 'runNow') {
    reply({ ok: true });
    getSched().then(l => { const e = l.find(x => x.id === m.id); if (e) autoRelist(e, true, modeOf(e) === 'auto'); });
    return false;
  }
  if (m && (m.type === 'setAuto' || m.type === 'setMode')) {
    getSched().then(async l => { const e = l.find(x => x.id === m.id); if (e) { const mode = m.mode || (m.auto ? 'auto' : 'remind'); e.mode = mode; e.auto = mode === 'auto'; if (mode === 'remind') { e.renewDays = 7; e.relistDays = 14; } else { e.renewDays = 0; e.relistDays = Math.min(7, Math.max(1, +m.days || 7)); } await putSched(l); arm(e); } reply({ ok: true }); });
    return true;
  }
  if (m && m.type === 'log') {
    log(m.what, m.title, m.caseNo, m.note); reply({ ok: true });
    return false;
  }
  if (m && m.type === 'cancelSched') {
    cancelSched(m.id).then(() => reply({ ok: true }));
    return true;
  }
  if (m && m.type === 'readUrl') {
    whoami().then(() => readSite(m.url)).then(() => reply({ ok: true }), err => reply({ error: err.message || String(err) }));
    return true;
  }
  if (m && m.type === 'f591') {
    (async () => { const p = await whoami(); await f591Check(); reply({ ok: true }); try { await f591Start(p); } catch (e) { notify('591 自動填寫沒有完成', e.message || String(e)); } })().catch(err => { try { reply({ error: err.message }); } catch (e) {} });
    return true;
  }
  if (m && m.type === 'rakuya') {
    (async () => { const p = await whoami(); reply({ ok: true }); await rakuyaStart(p); })().catch(err => { try { reply({ error: err.message }); } catch (e) {} });
    return true;
  }
  return false;
});

// ===== 樂屋網：開刊登頁 → 快速搬家匯入官網物件 → 補預設欄位（不按上架） =====
const RAKUYA_POST = 'https://member.rakuya.com.tw/sell/post/add';
async function rakuyaStart(p) {
  const { site } = await chrome.storage.local.get('site');
  if (!site || !site.url) throw new Error('還沒有讀取官網物件，請先貼上官網網址讀取。');
  const tab = await chrome.tabs.create({ url: RAKUYA_POST, active: true });
  await new Promise(resolve => {
    const t = setTimeout(done, 30000);
    function done() { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(); }
    function on(id, info) { if (id === tab.id && info.status === 'complete') done(); }
    chrome.tabs.onUpdated.addListener(on);
  });
  const now = await chrome.tabs.get(tab.id);
  if (!/member\.rakuya\.com\.tw\/sell\/post\/add/.test(now.url || '')) {
    notify('請先登入樂屋網', '已開啟樂屋網，請登入你自己的樂屋網帳號後，回到上架頁再按一次「填好樂屋網刊登」。');
    log('樂屋網填寫', site.title, site.caseNo, '未登入');
    return;
  }
  const profile = { name: p.name, phone: p.phone, line: p.line, lic: p.lic };
  const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: rakuyaFill, args: [{ url: site.url.split('?')[0], site, profile }] });
  const res = (r && r.result) || {};
  log('樂屋網填寫', site.title, site.caseNo, res.ok ? `已填好${res.warnings && res.warnings.length ? '；' + res.warnings.join('；') : ''}` : '失敗：' + (res.error || ''));
}

// ===== k7.com.tw 入口頁傳來的指令（只接受 k7.com.tw） =====
chrome.runtime.onMessageExternal.addListener((m, sender, reply) => {
  const origin = (sender && (sender.origin || sender.url)) || '';
  if (!/^https:\/\/(www\.)?k7\.com\.tw(\/|$)/.test(origin)) { reply({ error: 'forbidden' }); return false; }
  const v = chrome.runtime.getManifest().version;
  if (m && m.type === 'ping') {
    whoami().then(p => reply({ ok: true, version: v, profile: p }), err => reply({ ok: true, version: v, error: err.message }));
    return true;
  }
  if (m && m.type === 'readUrl') {
    whoami().then(() => readSite(m.url)).then(() => reply({ ok: true }), err => reply({ error: err.message || String(err) }));
    return true;
  }
  if (m && m.type === 'openSched') {
    chrome.tabs.create({ url: chrome.runtime.getURL('panel.html#sched') }); reply({ ok: true });
    return false;
  }
  // 同仁登記頁：Google 帳號一律由 Chrome 登入身分取得，不接受頁面自己填
  if (m && m.type === 'myEmail') {
    myEmail().then(email => reply({ ok: true, email }), () => reply({ ok: true, email: '' }));
    return true;
  }
  if (m && m.type === 'register') {
    (async () => {
      const email = await myEmail();
      if (!email) return reply({ error: '請先在 Chrome 右上角登入你的 Google 帳號，再重新整理這一頁。' });
      const r = await api({ action: 'register', email, name: m.name, phone: m.phone, line: m.line, lic: m.lic });
      if (r && r.ok) return reply({ ok: true, email, updated: !!r.updated });
      const why = { 'already-active': '這個帳號已經啟用，資料若要修改請洽管理者。', missing: '姓名、電話、營業員證號都要填。', email: 'Google 帳號格式不正確。', action: '名單程式還沒更新到可以登記的版本，請洽管理者。', 'not-listed': '名單程式還沒更新到可以登記的版本，請洽管理者。' };
      reply({ error: why[r && r.error] || '登記失敗，請稍後再試或洽管理者。' });
    })().catch(() => reply({ error: '連不到名單，請確認網路連線後再試。' }));
    return true;
  }
  reply({ error: 'unknown' }); return false;
});

// 在背景分頁打開官網物件頁（等同同仁自己打開），讀完就關掉
async function readSite(url) {
  const site = await readSiteData(url);
  await chrome.storage.local.set({ site });
  log('讀取官網物件', site.title, site.caseNo, `官網照片 ${site.photos.length} 張`);
  await chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') });
}
async function readSiteData(url) {
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await new Promise((resolve) => {
      const t = setTimeout(done, 30000);
      function done() { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(); }
      function on(id, info) { if (id === tab.id && info.status === 'complete') done(); }
      chrome.tabs.onUpdated.addListener(on);
    });
    let site = null;
    for (let i = 0; i < 15 && !site; i++) {
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['site-read.js'] });
        const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => readTwhgListing(document.body.innerText, document.title, location.href) });
        if (r && r.result && r.result.price) site = r.result;
      } catch (e) {}
      if (!site) await new Promise(r => setTimeout(r, 1000));
    }
    if (!site) throw new Error('讀不到這筆物件的價格。請確認網址正確、物件仍在官網上架中。');
    // 照片：先往下捲動讓延遲載入的照片出現，再讀取網址
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: async () => { for (const y of [0.25, 0.5, 0.75, 1, 0]) { window.scrollTo(0, document.body.scrollHeight * y); await new Promise(r => setTimeout(r, 500)); } } });
      const [ph] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: c => readTwhgPhotos(c), args: [site.caseNo || ''] });
      site.photos = (ph && ph.result) || [];
    } catch (e) { site.photos = []; }
    site.readAt = Date.now(); site.url = url;
    return site;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

const send = (tabId, method, params = {}) => chrome.debugger.sendCommand({ tabId }, method, params);

function waitLoad(tabId, ms = 20000) {
  return new Promise(resolve => {
    const t = setTimeout(done, ms);
    function done() { clearTimeout(t); chrome.debugger.onEvent.removeListener(on); resolve(); }
    function on(src, method) { if (src.tabId === tabId && method === 'Page.loadEventFired') done(); }
    chrome.debugger.onEvent.addListener(on);
  });
}

async function start() {
  const { job } = await chrome.storage.local.get('job');
  if (!job) return;
  const win = await chrome.windows.create({ url: 'about:blank', type: 'popup', width: 440, height: 920, focused: true });
  const tabId = win.tabs[0].id;
  await chrome.debugger.attach({ tabId }, '1.3');
  attached.add(tabId);
  await send(tabId, 'Page.enable');
  await send(tabId, 'Runtime.enable');
  tabJob[tabId] = { title: job.title, caseNo: job.caseNo || '', logged: false, auto: !!job.auto, winId: win.id };
  if (job.auto) setTimeout(() => { const t = tabJob[tabId]; if (t && !t.shared) notify('自動重新上架可能未完成', `${job.title}\n請查看手機模式視窗，必要時手動完成。`); }, 5 * 60 * 1000);
  await send(tabId, 'Emulation.setUserAgentOverride', { userAgent: MOBILE_UA, platform: 'Linux armv8l' });
  await send(tabId, 'Emulation.setDeviceMetricsOverride', { width: 412, height: 860, deviceScaleFactor: 2, mobile: true });
  await send(tabId, 'Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });
  // 之後每次換頁都自動載入「社團勾選助手」（按發佈後出現的分享到社團畫面）
  await send(tabId, 'Page.addScriptToEvaluateOnNewDocument', { source: `(${groupHelper.toString()})()` });
  const loaded = waitLoad(tabId);
  await send(tabId, 'Page.navigate', { url: FORM_URL });
  await loaded;
  await new Promise(r => setTimeout(r, 2500));
  // 在頁面裡執行填寫程式（不等它跑完，頁面自己會顯示進度條）
  await send(tabId, 'Runtime.evaluate', {
    expression: `(${groupHelper.toString()})();(${pageFill.toString()})(${JSON.stringify(job)})`,
    awaitPromise: false
  });
  await chrome.storage.local.remove('job');
}

chrome.tabs.onRemoved.addListener(tabId => {
  if (attached.has(tabId)) { attached.delete(tabId); chrome.debugger.detach({ tabId }).catch(() => {}); }
});
chrome.debugger.onDetach.addListener(src => attached.delete(src.tabId));
// 社團勾選助手偵測到「發佈後的社團清單」時會在頁面印出 CG_PUBLISHED，用來記錄「已發佈」
chrome.debugger.onEvent.addListener((src, method, params) => {
  if (method !== 'Runtime.consoleAPICalled') return;
  const t = tabJob[src.tabId];
  if (!t) return;
  const vals = (params.args || []).map(a => a.value);
  if (vals.includes('CG_PUBLISHED') && !t.logged) { t.logged = true; log('已發佈', t.title, t.caseNo); }
  if (vals.includes('CG_SHARED') && t.auto && !t.shared) {
    t.shared = true;
    log('自動重新上架完成', t.title, t.caseNo);
    notify('✔ 自動重新上架完成', t.title);
    setTimeout(() => chrome.windows.remove(t.winId).catch(() => {}), 8000);
  }
});

// ===== 排程：N 天後提醒「更新刊登」、M 天後提醒「重新上架」 =====
const DAY = 864e5;
const modeOf = e => e.mode || (e.auto ? 'auto' : 'remind');   // remind 提醒｜semi 半自動｜auto 全自動
const getSched = async () => (await chrome.storage.local.get('sched')).sched || [];
const putSched = l => chrome.storage.local.set({ sched: l });
function arm(e) {
  chrome.alarms.clear('renew|' + e.id); chrome.alarms.clear('relist|' + e.id);
  if (modeOf(e) === 'remind' && e.renewDays > 0) chrome.alarms.create('renew|' + e.id, { when: e.listedAt + e.renewDays * DAY });
  chrome.alarms.create('relist|' + e.id, { when: e.listedAt + e.relistDays * DAY });
}
async function addSchedule(opt) {
  const { job } = await chrome.storage.local.get('job');
  if (!job) return;
  const e = { id: 's' + Date.now(), title: job.title, caseNo: job.caseNo || '', url: job.url || '', mode: opt.mode || (opt.auto ? 'auto' : 'remind'), auto: (opt.mode || (opt.auto ? 'auto' : 'remind')) === 'auto', job: { title: job.title, price: job.price, description: job.description, photos: job.photos, caseNo: job.caseNo || '', site: job.site || null }, renewDays: (opt.mode || (opt.auto ? 'auto' : 'remind')) === 'remind' ? (+opt.renewDays || 7) : 0, relistDays: (opt.mode || (opt.auto ? 'auto' : 'remind')) === 'remind' ? (+opt.relistDays || 14) : Math.min(7, Math.max(1, +opt.relistDays || 7)), listedAt: Date.now() };
  const same = x => (e.caseNo && x.caseNo === e.caseNo) || x.title === e.title;
  const l = await getSched();
  for (const old of l.filter(same)) { chrome.alarms.clear('renew|' + old.id); chrome.alarms.clear('relist|' + old.id); }
  const kept = l.filter(x => !same(x)); kept.push(e); await putSched(kept); arm(e);   // 同一物件只保留一個排程
}
async function cancelSched(id) {
  chrome.alarms.clear('renew|' + id); chrome.alarms.clear('relist|' + id);
  await putSched((await getSched()).filter(x => x.id !== id));
}
async function relist(id) {
  const l = await getSched(), e = l.find(x => x.id === id);
  if (!e) return;
  const p = await whoami();
  e.listedAt = Date.now(); await putSched(l); arm(e);   // 重新上架後重新起算：再 7 天更新、14 天重新上架
  await chrome.storage.local.set({ job: { ...e.job, description: withFooter(e.job.description, p), at: Date.now() } });
  log('重新上架', e.title, e.caseNo);
  await start();
}
chrome.alarms.onAlarm.addListener(async a => {
  const [kind, id] = a.name.split('|');
  const e = (await getSched()).find(x => x.id === id);
  if (!e) return;
  const mode = modeOf(e);
  if (mode === 'auto' && kind === 'relist') { autoRelist(e, false, true); return; }
  if (mode !== 'remind' && kind === 'renew') return;   // 半自動／全自動不做更新
  if (mode === 'semi' && kind === 'relist') {
    chrome.notifications.create('semi|' + e.id + '|' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', requireInteraction: true, title: '澄果上架：該重新上架了（半自動）', message: `${e.title}\n點這則通知：自動刪除舊刊登並填好新刊登，發佈由你確認。` });
    return;
  }
  chrome.notifications.create(a.name + '|' + Date.now(), {
    type: 'basic', iconUrl: 'icons/icon128.png', requireInteraction: true,
    title: kind === 'renew' ? '澄果上架：該「更新」Marketplace 刊登了' : '澄果上架：該「重新上架」了',
    message: `${e.title}\n點這則通知開始處理。`
  });
});
chrome.notifications.onClicked.addListener(async nid => {
  chrome.notifications.clear(nid);
  const [kind, id] = nid.split('|');
  const e = (await getSched()).find(x => x.id === id);
  if (!e) return;
  if (kind === 'semi') { autoRelist(e, true, false); return; }
  try { await whoami(); } catch (err) { chrome.notifications.create('err|' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '澄果上架', message: err.message }); return; }
  const tab = await chrome.tabs.create({ url: 'https://www.facebook.com/marketplace/you/selling', active: true });
  await new Promise(resolve => {
    const t = setTimeout(done, 30000);
    function done() { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(); }
    function on(tid, info) { if (tid === tab.id && info.status === 'complete') done(); }
    chrome.tabs.onUpdated.addListener(on);
  });
  await new Promise(r => setTimeout(r, 2500));
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['fb-assist.js'] });
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: (k, t, i, c) => cgAssist(k, t, i, c), args: [kind, e.title, id, e.caseNo || ''] });
});

// ===== 全自動：刪除舊刊登 → 重讀官網 → 重新上架並發佈 =====
function notify(title, message) {
  chrome.notifications.create('info|' + Date.now(), { type: 'basic', iconUrl: 'icons/icon128.png', title: '澄果上架：' + title, message: message || '' });
}
async function openSelling(active) {
  const tab = await chrome.tabs.create({ url: 'https://www.facebook.com/marketplace/you/selling', active });
  await new Promise(resolve => {
    const t = setTimeout(done, 30000);
    function done() { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(); }
    function on(tid, info) { if (tid === tab.id && info.status === 'complete') done(); }
    chrome.tabs.onUpdated.addListener(on);
  });
  await new Promise(r => setTimeout(r, 3000));
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['fb-assist.js'] });
  return tab;
}
const DEL_REASON = { 'not-found': '在「你的商品」找不到舊刊登', multiple: '找到兩筆以上同名刊登，為避免刪錯已停止', 'no-menu': '找不到刊登的「⋯」選單', 'no-delete-item': '選單裡找不到「刪除」', 'still-there': '按了刪除但刊登仍在' };
async function autoRelist(e, watching, publish = true) {
  const tag = publish ? '全自動' : '半自動';
  try {
    const p = await whoami();
    // 1. 重讀官網：讀不到就視為已下架，停止排程
    let job = { ...e.job };
    if (e.url) {
      let site = null;
      try { site = await readSiteData(e.url); } catch (err) { site = null; }
      if (!site) {
        await cancelSched(e.id);
        log('自動停止（官網已下架）', e.title, e.caseNo);
        notify('官網已讀不到，已停止排程', `${e.title}\n物件可能已成交或下架，舊刊登請自行標示售出或刪除。`);
        return;
      }
      const newTitle = e.title.replace(/[\d.,]+萬\s*$/, `${site.price}萬`);
      job = { ...job, title: newTitle, price: String(Math.round(parseFloat(site.price) * 10000)), description: withFooter(cgBody(site, site.price), p), caseNo: site.caseNo || e.caseNo };
    } else {
      job.description = withFooter(job.description, p);
    }
    // 2. 刪除舊刊登（必須唯一相符才刪）
    const tab = await openSelling(!!watching);
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: t => cgAutoDelete(t), args: [e.title] });
    const res = (r && r.result) || { ok: false, reason: 'unknown' };
    if (!res.ok && res.reason !== 'not-found') {
      log('自動重新上架失敗', e.title, e.caseNo, DEL_REASON[res.reason] || res.reason);
      notify(`${tag}重新上架未執行`, `${e.title}\n${DEL_REASON[res.reason] || res.reason}，請手動處理。`);
      return;
    }
    if (!watching) chrome.tabs.remove(tab.id).catch(() => {});
    log(res.ok ? '自動刪除舊刊登' : '自動重新上架（未找到舊刊登）', e.title, e.caseNo);
    // 3. 重新上架並自動發佈
    const l = await getSched(), cur = l.find(x => x.id === e.id);
    if (cur) { cur.title = job.title; cur.job = { ...cur.job, title: job.title, price: job.price, description: job.description, caseNo: job.caseNo }; cur.listedAt = Date.now(); await putSched(l); arm(cur); }
    await chrome.storage.local.set({ job: { ...job, auto: !!publish, at: Date.now() } });
    log('重新上架', job.title, job.caseNo, tag);
    if (!publish) notify('半自動：已填好新刊登', `${job.title}\n請在手機模式視窗檢查後按「發佈」，再確認社團並分享。`);
    await start();
  } catch (err) {
    log('自動重新上架失敗', e.title, e.caseNo, err.message);
    notify('自動重新上架失敗', `${e.title}\n${err.message}`);
  }
}
// 更新或開啟時，把同一物件的重複排程合併成一個（保留最新的）
async function dedupeSched() {
  const l = await getSched(), seen = new Map();
  for (const e of l.sort((a, b) => b.listedAt - a.listedAt)) { const k = e.caseNo || e.title; if (!seen.has(k)) seen.set(k, e); else { chrome.alarms.clear('renew|' + e.id); chrome.alarms.clear('relist|' + e.id); } }
  if (seen.size !== l.length) await putSched([...seen.values()]);
}
chrome.runtime.onInstalled.addListener(() => dedupeSched());
chrome.runtime.onStartup.addListener(() => dedupeSched());

// 臨時下架：刪除 Facebook 上這筆（同標題全部）刊登，並停止排程
async function takedown(e) {
  try {
    await whoami();
    const tab = await openSelling(true);
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: t => cgAutoDelete(t, true), args: [e.title] });
    const res = (r && r.result) || { ok: false, reason: 'unknown' };
    if (res.ok || res.reason === 'not-found') {
      await cancelSched(e.id);
      log('下架刪除', e.title, e.caseNo, res.ok ? `刪除 ${res.deleted || 1} 筆` : '找不到刊登，僅停止排程');
      notify('已下架', `${e.title}\n${res.ok ? `已從 Facebook 刪除 ${res.deleted || 1} 筆刊登，` : '在「你的商品」找不到這筆刊登，'}排程已停止。`);
      setTimeout(() => chrome.tabs.remove(tab.id).catch(() => {}), 5000);
    } else {
      log('下架失敗', e.title, e.caseNo, DEL_REASON[res.reason] || res.reason);
      notify('下架未完成', `${e.title}\n${DEL_REASON[res.reason] || res.reason}。排程未停止，請手動刪除後再按「停止排程」。`);
    }
  } catch (err) { notify('下架失敗', `${e.title}\n${err.message}`); }
}
async function autoRenew(e) {
  try {
    await whoami();
    const tab = await openSelling(false);
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: (k, t, i, c) => cgAssist(k, t, i, c), args: ['renew', e.title, e.id, e.caseNo || ''] });
    setTimeout(() => chrome.tabs.remove(tab.id).catch(() => {}), 30000);
  } catch (err) { notify('自動更新失敗', `${e.title}\n${err.message}`); }
}

// ===== 以下在 Facebook 頁面中執行 =====
async function pageFill(job) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const byText = t => [...document.querySelectorAll('[role=button],button,div,span,label')].filter(e => e.textContent.trim() === t).pop();
  const waitFor = async (fn, ms = 15000) => { const end = Date.now() + ms; while (Date.now() < end) { const v = fn(); if (v) return v; await sleep(250); } return null; };
  const tap = el => (el.closest('[role=button],button') || el).click();
  const field = label => [...document.querySelectorAll('input,textarea')].find(e => (e.getAttribute('aria-label') || e.placeholder || '') === label);
  const setVal = (el, v) => {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:2147483647;padding:12px 14px;font:15px/1.5 sans-serif;color:#fff;background:#FD7305;pointer-events:none;box-shadow:0 -2px 8px rgba(0,0,0,.2)';
  const show = (t, bg) => { bar.textContent = t; if (bg) bar.style.background = bg; if (!bar.isConnected) document.body.appendChild(bar); };
  const fail = t => show('澄果上架：' + t + '　請改用小幫手第 5 步手動複製。', '#b42318');

  show('澄果上架：自動填寫中，請先不要操作這個視窗…');
  const later = byText('稍後再說'); if (later) tap(later);

  // 1. 類別：房屋銷售
  if (!(await waitFor(() => byText('請選擇') || byText('房屋銷售')))) return fail('找不到刊登表單，請確認已登入 Facebook。');
  if (!byText('房屋銷售')) {
    tap(byText('請選擇'));
    const sale = await waitFor(() => byText('房屋銷售'), 8000);
    if (!sale) return fail('類別清單裡找不到「房屋銷售」。');
    tap(sale);
    await sleep(2000);
  }

  // 2. 標題、價格、說明
  const title = await waitFor(() => field('你想賣些什麼？'));
  if (!title) return fail('找不到標題欄。');
  setVal(title, job.title);
  const price = field('價格（NT$）'); if (price) setVal(price, job.price);
  const desc = field('說明'); if (desc) setVal(desc, job.description);
  show('澄果上架：文字已填好，正在放照片…');

  // 3. 照片（一次一張：新增相片 → 上傳相片 → 儲存）
  const toFile = async (dataUrl, i) => { const b = atob(dataUrl.split(',')[1]); const u = new Uint8Array(b.length); for (let k = 0; k < b.length; k++) u[k] = b.charCodeAt(k); return new File([u], `photo${String(i + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }); };
  const orig = HTMLInputElement.prototype.click;
  let pending = null, done = 0;
  HTMLInputElement.prototype.click = function () {
    if (this.type === 'file' && pending) {
      const dt = new DataTransfer(); dt.items.add(pending); pending = null;
      this.files = dt.files; this.dispatchEvent(new Event('change', { bubbles: true })); return;
    }
    return orig.call(this);
  };
  try {
    for (let i = 0; i < Math.min(job.photos.length, 10); i++) {
      const add = await waitFor(() => byText('新增相片'), 10000); if (!add) break;
      tap(add);
      const up = await waitFor(() => byText('上傳相片'), 8000); if (!up) break;
      pending = await toFile(job.photos[i], i);
      tap(up);
      const save = await waitFor(() => byText('儲存'), 15000); if (!save) break;
      tap(save);
      await sleep(1500);
      done++;
      show(`澄果上架：照片 ${done} / ${job.photos.length}…`);
    }
  } finally { HTMLInputElement.prototype.click = orig; }
  const ok = byText('確定'); if (ok && /最多/.test(document.body.innerText)) tap(ok);

  // 4. 再確認一次文字沒有被頁面清掉
  const t2 = field('你想賣些什麼？'); if (t2 && !t2.value) setVal(t2, job.title);
  const p2 = field('價格（NT$）'); if (p2 && !p2.value) setVal(p2, job.price);
  const d2 = field('說明'); if (d2 && !d2.value) setVal(d2, job.description);

  if (job.auto) {
    try { sessionStorage.setItem('cgAuto', '1'); } catch (e) {}
    show(`澄果上架（全自動）：已填好（照片 ${done} 張），3 秒後自動發佈…`, '#b45309');
    await sleep(3000);
    const pub = [...document.querySelectorAll('[role=button],button,div,span')].filter(e => e.textContent.trim() === '發佈');
    const b = pub.pop();
    if (b) { tap(b); show('澄果上架（全自動）：已按發佈，等待社團清單…', '#b45309'); }
    else show('澄果上架（全自動）：找不到「發佈」按鈕，請手動按發佈。', '#b42318');
    return;
  }
  show(`✔ 已填好（照片 ${done} 張）。請檢查標題、價格、說明與照片，確認無誤後自己按右上角「發佈」。`, '#18794e');
}

// ===== 社團勾選助手：按「發佈」後出現分享到社團的清單時，自動勾選前 20 個，不會按分享 =====
function groupHelper() {
  if (window.__cgGroups) return; window.__cgGroups = true;
  const MAX = 20, until = Date.now() + 20 * 60 * 1000;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const SEL = 'input[type=checkbox],[role=checkbox],[aria-checked]';
  const boxesIn = el => [...el.querySelectorAll(SEL)].filter(b => b.getAttribute('role') !== 'switch' && b.getAttribute('role') !== 'radio');
  const isOn = b => b.tagName === 'INPUT' ? b.checked : b.getAttribute('aria-checked') === 'true';
  const note = t => {
    let b = document.getElementById('cg-note');
    if (!b) { b = document.createElement('div'); b.id = 'cg-note'; b.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:2147483647;padding:12px 14px;font:15px/1.5 sans-serif;color:#fff;background:#18794e;pointer-events:none;box-shadow:0 -2px 8px rgba(0,0,0,.2)'; (document.body || document.documentElement).appendChild(b); }
    b.textContent = t;
  };
  const findPanel = () => {
    const c = [...document.querySelectorAll('[role=dialog],[role=list],form,section,div')]
      .filter(d => /社團/.test(d.innerText || '') && boxesIn(d).length >= 2);
    c.sort((a, b) => boxesIn(b).length - boxesIn(a).length || a.querySelectorAll('*').length - b.querySelectorAll('*').length);
    return c[0];
  };
  const top = (panel) => { const all = boxesIn(panel); return all.filter(b => !all.some(o => o !== b && o.contains(b))); };
  const on = b => isOn(b) || !!b.querySelector('input:checked,[aria-checked=true]');
  const txt = e => (e && (e.innerText || e.textContent) || '').replace(/\s+/g, ' ').trim();
  const keyOf = b => (txt(b) || txt(b.closest('label,[role=listitem],li')) || txt(b.parentElement)).slice(0, 80);
  async function setState(b, want) {
    if (on(b) === want) return;
    const targets = [b.tagName === 'INPUT' ? (b.closest('label') || b) : b, b.querySelector('input,[role=checkbox]'), b.closest('label')].filter(Boolean);
    for (const el of targets) { el.click(); await sleep(250); if (on(b) === want) return; }
  }
  let busy = false;
  async function tick(panel) {
    busy = true; panel.dataset.cgDone = '1';
    try { console.log('CG_PUBLISHED'); } catch (e) {}
    const seen = new Set(); let idx = 0, picked = 0;
    for (let round = 0; round < 20; round++) {
      for (const b of top(panel)) {
        const k = keyOf(b) || ('#' + idx);
        if (seen.has(k)) continue; seen.add(k);
        if (b.disabled || b.getAttribute('aria-disabled') === 'true') { idx++; continue; }
        const want = idx < MAX;          // 固定：前 20 個勾選，其餘取消
        await setState(b, want);
        if (on(b)) picked++;
        idx++;
      }
      const sc = [panel, ...panel.querySelectorAll('*')].find(e => e.scrollHeight > e.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(e).overflowY));
      if (!sc) break;
      const before = seen.size; sc.scrollTop = sc.scrollHeight; await sleep(900);
      if (top(panel).every(b => seen.has(keyOf(b))) && seen.size === before) break;
    }
    const sc0 = [panel, ...panel.querySelectorAll('*')].find(e => e.scrollHeight > e.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(e).overflowY));
    if (sc0) sc0.scrollTop = 0;
    let auto = false; try { auto = sessionStorage.getItem('cgAuto') === '1'; } catch (e) {}
    if (auto && picked) {
      await sleep(1500);
      const scope = panel.closest('[role=dialog]') || panel;
      const share = [...scope.querySelectorAll('[role=button],button')].concat([...document.querySelectorAll('[role=button],button')]).find(b => /^(分享|發佈|發布|完成|貼文|Post|Share)$/.test((b.innerText || b.getAttribute('aria-label') || '').trim()));
      if (share) { share.click(); try { sessionStorage.removeItem('cgAuto'); } catch (e) {} note(`澄果上架（全自動）：已勾選 ${picked} 個社團並分享。`); try { console.log('CG_SHARED'); } catch (e) {} }
      else note('澄果上架（全自動）：找不到「分享」按鈕，請手動按分享。');
      busy = false; return;
    }
    note(picked ? `澄果上架：已固定勾選前 ${picked} 個社團（第 ${MAX + 1} 個以後已取消），請確認後自己按「分享」或「發佈」。` : '澄果上架：找不到可勾選的社團，請手動勾選。');
    busy = false;
  }
  let t = null;
  const obs = new MutationObserver(() => {
    if (Date.now() > until) { obs.disconnect(); return; }
    clearTimeout(t);
    t = setTimeout(() => { if (busy) return; const p = findPanel(); if (p && !p.dataset.cgDone) tick(p); }, 600);
  });
  const check = () => { if (busy || Date.now() > until) return; const p = findPanel(); if (p && !p.dataset.cgDone) tick(p); };
  const iv = setInterval(() => { if (Date.now() > until) clearInterval(iv); else check(); }, 2000);
  const go = () => { obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-checked'] }); check(); };
  if (document.documentElement) go(); else document.addEventListener('DOMContentLoaded', go);
}


// ===== 591：開刊登頁 → 第一步選用途／現況／型態 → 填寫資料與照片（不按保存、不付款） =====
const F591_FIRST = 'https://user.591.com.tw/post/first?type=sale';
function waitTab(tabId, test, ms = 30000) {
  return new Promise(resolve => {
    const t = setTimeout(() => done(false), ms);
    function done(v) { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(v); }
    function on(id, info, tab) { if (id === tabId && info.status === 'complete' && test(tab.url || '')) done(true); }
    chrome.tabs.onUpdated.addListener(on);
    chrome.tabs.get(tabId).then(tab => { if (tab.status === 'complete' && test(tab.url || '')) done(true); }).catch(() => {});
  });
}
async function toDataUrl(blob, max = 1600) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 });
  const buf = new Uint8Array(await out.arrayBuffer()); let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return 'data:image/jpeg;base64,' + btoa(bin);
}
async function f591Check() {
  const { site } = await chrome.storage.local.get('site');
  if (!site || !site.url) throw new Error('還沒有讀取官網物件，請先貼上官網網址讀取。');
  if (site.floor === undefined) throw new Error('這筆官網資料是舊版擴充功能讀的，請到 k7.com.tw/listing 重新讀取一次官網物件。');
}
async function f591Start(p) {
  const { site } = await chrome.storage.local.get('site');
  // 先把官網照片準備好（最多 30 張）
  const photos = [];
  for (const u of (site.photos || []).slice(0, 30)) {
    try { const r = await fetch(u, { credentials: 'omit' }); if (!r.ok) continue; const b = await r.blob(); if (!/^image\//.test(b.type) || b.size < 8000) continue; photos.push(await toDataUrl(b)); } catch (e) {}
  }
  const tab = await chrome.tabs.create({ url: F591_FIRST, active: true });
  await waitTab(tab.id, () => true);
  const now = await chrome.tabs.get(tab.id);
  if (!/user\.591\.com\.tw\/post\//.test(now.url || '')) {
    notify('請先登入 591', '已開啟 591，請登入你自己的 591 帳號後，回到上架頁再按一次「填好 591 刊登」。');
    log('591填寫', site.title, site.caseNo, '未登入');
    return;
  }
  const [r1] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: f591Step1, args: [{ site }] });
  const s1 = (r1 && r1.result) || {};
  if (!s1.ok) { notify('591 自動填寫沒有完成', s1.error || '第一步選擇失敗，請手動操作。'); log('591填寫', site.title, site.caseNo, '失敗：' + (s1.error || '')); return; }
  const reached = await waitTab(tab.id, u => /\/post\/two\/sale/.test(u), 30000);
  if (!reached) { notify('591 自動填寫沒有完成', `已選「${s1.purpose}／${s1.kind}」，但沒有進到填寫頁${s1.note ? '（' + s1.note + '）' : ''}，請手動選擇房屋型態。`); log('591填寫', site.title, site.caseNo, '未進入填寫頁'); return; }
  await new Promise(r => setTimeout(r, 2500));
  const profile = { name: p.name, phone: p.phone, line: p.line, lic: p.lic };
  const [r2] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: f591Fill, args: [{ site, profile, photos }] });
  const res = (r2 && r2.result) || {};
  log('591填寫', site.title, site.caseNo, res.ok ? `已填好，照片 ${res.photos} 張` : '失敗：' + (res.error || ''));
}
