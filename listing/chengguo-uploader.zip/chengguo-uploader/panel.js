const $ = id => document.getElementById(id);
const MAXP = 10;
const SKIP = /評估|分析|謄本|產調|回報|建議書|配案/;
const CSNAME = /(^|[^a-z])cs([^a-z]|$)|case\s*stud|委託|資料表|物件表|銷售表/i;
let site = null, photos = [], me = null, sitePhotos = null, folderPhotos = [];

function footer(c) {
  const contact = [c.name && `聯絡人：${c.name}`, c.phone && `電話：${c.phone}`, c.line && `LINE：${c.line}`, c.lic && `營業員證號：${c.lic}`].filter(Boolean).join('｜');
  return ['', '——————', '台灣房屋 澄果團隊（澄果資產有限公司）', contact, '店址：高雄市鼓山區青海路416號｜店電：07-9766977', '物件資訊以現況及產權登記資料為準', '經紀人：邱秀琴(109)屏縣字第000147號'].filter((x, i) => i === 0 || x).join('\n');
}
const cfg = () => me || {};

const body = (s, price) => cgBody(s, price);

function refreshFooter() {
  const v = $('oDesc').value, i = v.indexOf('\n——————');
  $('oDesc').value = (i >= 0 ? v.slice(0, i) : v).replace(/\s+$/, '') + '\n' + footer(cfg());
}

function render() {
  const s = site;
  $('src').textContent = `官網物件編號 ${s.caseNo || '—'}　讀取時間 ${new Date(s.readAt).toLocaleString('zh-TW')}`;
  const rows = [['官網標題', s.title], ['售價', s.price && s.price + ' 萬'], ['社區', s.community], ['位置', `${s.district}${s.road}`], ['型態', s.type], ['用途', s.use], ['格局', s.layout], ['建坪', s.areaTotal], ['主建物', s.areaMain && s.areaMain + ' 坪'], ['主＋陽', s.areaMainBalcony && s.areaMainBalcony + ' 坪'], ['地坪', s.areaLand && s.areaLand + ' 坪'], ['屋齡', s.age && s.age + ' 年'], ['車位', s.parking], ['管理費', s.fee], ['座向', s.facing], ['特色', (s.tags || []).join('、')]];
  $('kv').replaceChildren(...rows.flatMap(([k, v]) => { const a = document.createElement('span'); a.textContent = k; const b = document.createElement('span'); b.textContent = v || '—'; return [a, b]; }));
  let t = [s.district, s.title, s.price && s.price + '萬'].filter(Boolean).join(' ');
  $('oTitle').value = t.length > 70 ? t.slice(0, 70) : t;
  $('oPrice').value = s.price || '';
  $('oDesc').value = body(s, s.price) + '\n' + footer(cfg());
}

/* 照片 */
const rank = n => /^\d+/.test(n) ? 1 : /格局/.test(n) ? 2 : /公設/.test(n) ? 3 : 4;
$('pickDir').onchange = e => {
  folderPhotos.forEach(p => URL.revokeObjectURL(p.url));
  photos = folderPhotos = [...e.target.files]
    .filter(f => (f.webkitRelativePath || f.name).split('/').length <= 2)
    .filter(f => /\.(jpe?g|png|webp)$/i.test(f.name) && !SKIP.test(f.name) && !CSNAME.test(f.name.replace(/\.[^.]+$/, '')))
    .map(f => ({ f, name: f.name, sel: false, url: URL.createObjectURL(f) }))
    .sort((a, b) => rank(a.name) - rank(b.name) || a.name.localeCompare(b.name, 'zh-Hant', { numeric: true }));
  let k = 0; for (const p of photos) { p.sel = !/配置/.test(p.name) && k < MAXP; if (p.sel) k++; }
  renderPhotos();
};
function renderPhotos() {
  let k = 0;
  $('photos').innerHTML = '';
  photos.forEach((p, i) => {
    const d = document.createElement('div'); d.className = 'ph' + (p.sel ? ' sel' : '');
    if (p.sel) { const n = document.createElement('span'); n.className = 'n'; n.textContent = ++k; d.appendChild(n); }
    const im = document.createElement('img'); im.src = p.url; im.alt = p.name; im.dataset.i = i; d.appendChild(im);
    const bar = document.createElement('div'); bar.className = 'bar';
    const l = document.createElement('button'); l.textContent = '◀'; l.dataset.mv = i; l.dataset.d = -1;
    const nm = document.createElement('span'); nm.textContent = p.name;
    const r = document.createElement('button'); r.textContent = '▶'; r.dataset.mv = i; r.dataset.d = 1;
    bar.append(l, nm, r); d.appendChild(bar); $('photos').appendChild(d);
  });
  $('phCount').textContent = photos.length ? `已選 ${k} / ${MAXP} 張（共 ${photos.length} 張）` : '';
}
$('photos').onclick = e => {
  const im = e.target.closest('img');
  if (im) { const p = photos[+im.dataset.i]; if (!p.sel && photos.filter(x => x.sel).length >= MAXP) { $('msg').textContent = `最多 ${MAXP} 張，請先取消一張`; return; } p.sel = !p.sel; renderPhotos(); return; }
  const b = e.target.closest('[data-mv]');
  if (b) { const i = +b.dataset.mv, j = i + +b.dataset.d; if (j < 0 || j >= photos.length) return; [photos[i], photos[j]] = [photos[j], photos[i]]; renderPhotos(); }
};

async function loadSitePhotos() {
  if (sitePhotos) return sitePhotos;
  const list = (site && site.photos || []).slice(0, 15);
  const out = [];
  for (let i = 0; i < list.length; i++) {
    $('srcHint').textContent = `下載官網照片 ${i + 1} / ${list.length}…`;
    try {
      const r = await fetch(list[i], { credentials: 'omit' });
      if (!r.ok) continue;
      const b = await r.blob();
      if (!/^image\//.test(b.type) || b.size < 8000) continue;     // 太小的多半是圖示
      out.push({ f: b, name: `官網照片 ${String(out.length + 1).padStart(2, '0')}`, sel: false, url: URL.createObjectURL(b) });
    } catch (e) {}
  }
  out.forEach((p, i) => p.sel = i < MAXP);
  return (sitePhotos = out);
}
async function useSource(src) {
  $('folderRow').hidden = src !== 'folder';
  if (src === 'site') {
    $('srcSite').checked = true;
    const l = await loadSitePhotos();
    if (!l.length) {
      $('srcHint').innerHTML = '<span class="err">官網照片抓不到或下載失敗，已改用「從物件資料夾選」。</span>';
      $('srcFolder').checked = true; $('folderRow').hidden = false; photos = folderPhotos; renderPhotos(); return;
    }
    $('srcHint').textContent = `已從官網取得 ${l.length} 張，預設選前 ${Math.min(MAXP, l.length)} 張。請確認是這筆物件的照片，可點選取消或調整順序。`;
    photos = l;
  } else {
    $('srcFolder').checked = true;
    $('srcHint').textContent = '選物件資料夾。A 開頭的子資料夾、CS 表與配置圖不會選入。';
    photos = folderPhotos;
  }
  renderPhotos();
}
$('srcSite').onchange = () => useSource('site');
$('srcFolder').onchange = () => useSource('folder');

async function shrink(file, max = 1600) {
  const bmp = await createImageBitmap(file);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 });
  return new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(out); });
}

$('btnGo').onclick = async () => {
  const msg = $('msg');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認，無法上架。</span>'; return; }
  const price = parseFloat($('oPrice').value);
  if (!$('oTitle').value.trim() || !isFinite(price)) { msg.innerHTML = '<span class="err">標題或價格是空的。</span>'; return; }
  const sel = photos.filter(p => p.sel);
  if (!sel.length) { msg.innerHTML = '<span class="err">請先選照片（官網照片或物件資料夾）。</span>'; return; }
  refreshFooter();
  $('btnGo').disabled = true;
  try {
    const out = [];
    for (let i = 0; i < sel.length; i++) { msg.textContent = `處理照片 ${i + 1} / ${sel.length}…`; out.push(await shrink(sel[i].f)); }
    const job = { title: $('oTitle').value.trim(), price: String(Math.round(price * 10000)), description: $('oDesc').value, photos: out, caseNo: (site && site.caseNo) || '', url: (site && site.url) || '', at: Date.now() };
    await chrome.storage.local.set({ job });
    const mode = curMode();
    const sch = !$('schOn').checked ? null : mode === 'remind'
      ? { mode, renewDays: +$('renewDays').value || 7, relistDays: +$('relistDays').value || 14 }
      : { mode, renewDays: 0, relistDays: +$('autoDays').value || 7 };
    chrome.storage.local.set({ schedDefaults: { renewDays: +$('renewDays').value || 7, relistDays: +$('relistDays').value || 14, mode, autoDays: +$('autoDays').value || 7 } });
    const res = await chrome.runtime.sendMessage({ type: 'start', schedule: sch });
    if (res && res.error) throw new Error(res.error);
    setTimeout(renderSched, 1500);
    msg.textContent = '已開啟手機模式視窗，正在自動填寫。完成後請檢查並自己按「發佈」。';
  } catch (e) { msg.innerHTML = '<span class="err">發生錯誤：' + (e.message || e) + '</span>'; }
  $('btnGo').disabled = false;
};

$('btnRakuya').onclick = async () => {
  const msg = $('msgR');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認。</span>'; return; }
  if (!site || !site.url) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  $('btnRakuya').disabled = true; msg.textContent = '開啟樂屋網刊登頁中…';
  const res = await chrome.runtime.sendMessage({ type: 'rakuya' });
  $('btnRakuya').disabled = false;
  msg.innerHTML = res && res.error ? '<span class="err">' + res.error + '</span>' : '已開啟樂屋網（新分頁），頁面上方會顯示填寫進度與需要確認的地方。';
};

$('btn591').onclick = async () => {
  const msg = $('msg591');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認。</span>'; return; }
  if (!site || !site.url) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  const pick = (document.querySelector('input[name=p591]:checked') || {}).value === 'pick';
  const sel = photos.filter(p => p.sel);
  if (pick && !sel.length) { msg.innerHTML = '<span class="err">請先在上方選照片，或改選「官網全部照片」。</span>'; return; }
  $('btn591').disabled = true;
  if (pick) {   // 用同仁選好的照片與順序
    const out = [];
    for (let i = 0; i < sel.length; i++) { msg.textContent = `處理照片 ${i + 1} / ${sel.length}…`; out.push(await shrink(sel[i].f)); }
    await chrome.storage.local.set({ f591Photos: out });
  } else await chrome.storage.local.remove('f591Photos');
  msg.textContent = '準備照片並開啟 591 中，約 10～30 秒…';
  const res = await chrome.runtime.sendMessage({ type: 'f591' });
  $('btn591').disabled = false;
  msg.innerHTML = res && res.error ? '<span class="err">' + res.error + '</span>' : '已開啟 591（新分頁），頁面上方會顯示填寫進度與需要確認的地方。';
};

// 兩段式確認（擴充功能頁不使用 confirm 對話框）：第一次按顯示警告，3 秒內再按才執行
const curMode = () => (document.querySelector('input[name=mode]:checked') || {}).value || 'remind';
const MODE_NAME = { remind: '提醒', semi: '半自動', auto: '全自動' };
function confirmBox(btn, warn) {
  if (btn.dataset.armed === '1') { btn.dataset.armed = ''; return true; }
  btn.dataset.armed = '1'; const old = btn.textContent; btn.textContent = '再按一次確認'; $('msg').textContent = warn;
  setTimeout(() => { if (btn.dataset.armed === '1') { btn.dataset.armed = ''; btn.textContent = old; } }, 4000);
  return false;
}
async function renderSched() {
  const { sched = [] } = await chrome.storage.local.get('sched');
  const box = $('schedList'); box.innerHTML = '';
  if (!sched.length) { box.textContent = '目前沒有排程。'; return; }
  const fmt = t => new Date(t).toLocaleString('zh-TW', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  for (const e of sched) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;flex-wrap:wrap;gap:10px;align-items:center;border-top:1px solid var(--line);padding:10px 0;color:var(--ink);font-size:15px';
    const t = document.createElement('span'); t.style.flex = '1 1 260px';
    const mode = e.mode || (e.auto ? 'auto' : 'remind');
    t.textContent = mode !== 'remind'
      ? `${e.title}　上架 ${fmt(e.listedAt)}｜${MODE_NAME[mode]}：每 ${e.relistDays} 天，下次 ${fmt(e.listedAt + e.relistDays * 864e5)}`
      : `${e.title}　上架 ${fmt(e.listedAt)}｜更新 ${fmt(e.listedAt + e.renewDays * 864e5)}｜重新上架 ${fmt(e.listedAt + e.relistDays * 864e5)}`;
    const au = document.createElement('span'); au.style.cssText = 'display:flex;gap:6px;align-items:center';
    const css = 'font:inherit;font-size:14px;padding:4px 6px;border:1px solid var(--line);border-radius:3px';
    const ms = document.createElement('select'); ms.style.cssText = css;
    for (const [v, n] of Object.entries(MODE_NAME)) { const o = document.createElement('option'); o.value = v; o.textContent = n; ms.appendChild(o); }
    ms.value = mode;
    const sel = document.createElement('select'); sel.style.cssText = css;
    for (let d = 1; d <= 7; d++) { const o = document.createElement('option'); o.value = d; o.textContent = `每 ${d} 天`; sel.appendChild(o); }
    sel.value = mode === 'remind' ? 7 : Math.min(7, Math.max(1, e.relistDays)); sel.hidden = mode === 'remind';
    const save = async () => { await chrome.runtime.sendMessage({ type: 'setMode', id: e.id, mode: ms.value, days: +sel.value }); renderSched(); };
    ms.onchange = save; sel.onchange = save;
    au.append(ms, sel);
    const now = document.createElement('button'); now.textContent = mode === 'auto' ? '立即執行一次（測試）' : '立即刪舊並重新上架';
    now.onclick = async () => {
      if (!confirmBox(now, `會立刻刪除「${e.title}」的舊刊登並重新上架${mode === 'auto' ? '（自動發佈）' : '（發佈由你按）'}，刪除後無法復原。再按一次確認執行。`)) return;
      await chrome.runtime.sendMessage({ type: 'runNow', id: e.id }); now.textContent = '執行中，請看開啟的視窗…'; now.disabled = true;
      setTimeout(renderSched, 20000);
    };
    const b = document.createElement('button'); b.textContent = '只停止排程'; b.title = '不刪除 Facebook 上的刊登';
    b.onclick = async () => { await chrome.runtime.sendMessage({ type: 'cancelSched', id: e.id }); renderSched(); };
    const td = document.createElement('button'); td.textContent = '下架並刪除'; td.style.cssText = 'color:#b42318;border-color:#f0b4ae';
    td.onclick = async () => {
      if (!confirmBox(td, `會從 Facebook 刪除「${e.title}」的刊登（同標題全部）並停止排程，刪除後無法復原。再按一次確認。`)) return;
      await chrome.runtime.sendMessage({ type: 'takedown', id: e.id }); td.textContent = '下架中，請看開啟的視窗…'; td.disabled = true;
      setTimeout(renderSched, 20000);
    };
    row.append(t, au, now, td, b); box.appendChild(row);
  }
}

(async () => {
  renderSched();
  const st = await chrome.storage.local.get(['site', 'schedDefaults']);
  const d = st.schedDefaults || {};
  $('renewDays').value = d.renewDays || 7; $('relistDays').value = d.relistDays || 14; $('autoDays').value = d.autoDays || 7;
  const m0 = d.mode || (d.auto ? 'auto' : 'remind');
  document.querySelector(`input[name=mode][value=${m0}]`).checked = true;
  const syncMode = () => { const m = curMode(); $('autoRow').hidden = m === 'remind'; $('manualRow').hidden = m !== 'remind'; };
  document.querySelectorAll('input[name=mode]').forEach(r => r.onchange = syncMode); syncMode();
  const who = await chrome.runtime.sendMessage({ type: 'whoami' });
  if (who && who.ok) {
    me = who.profile;
    const rows = [['Google 帳號', me.email], ['聯絡人', me.name], ['電話', me.phone], ['LINE', me.line || '—'], ['營業員證號', me.lic]];
    $('me').replaceChildren(...rows.flatMap(([k, v]) => { const a = document.createElement('span'); a.textContent = k; const b = document.createElement('span'); b.textContent = v || '—'; return [a, b]; }));
  } else {
    $('me').innerHTML = '';
    const e = document.createElement('span'); e.className = 'err'; e.style.gridColumn = '1/-1'; e.textContent = (who && who.error) || '無法確認身分。'; $('me').appendChild(e);
    $('btnGo').disabled = true;
  }
  site = st.site;
  if (!site) { $('src').textContent = '還沒有讀取官網物件。請先在 Chrome 打開台灣房屋官網的物件頁，再按「澄果上架」→「讀取這個官網物件」。'; return; }
  render();
  useSource(site.photos && site.photos.length ? 'site' : 'folder');
})();

// 廣告用語檢查：標題、說明有容易被認定為不實或誇大的字眼就用黃色提醒（只提醒，不擋上架）
(() => {
  let last = null;
  const run = () => {
    const t = document.getElementById('oTitle'), d = document.getElementById('oDesc'), box = document.getElementById('adWarn');
    if (!t || !d || !box || typeof cgAdRisk !== 'function') return;
    const v = t.value + '\n' + d.value; if (v === last) return; last = v;
    const hits = cgAdRisk(v);
    box.hidden = !hits.length;
    box.textContent = hits.length ? '⚠ 廣告用語提醒：' + hits.map(h => `「${h.word}」（${h.why}）`).join('、') + '。容易被認定為不實或誇大廣告，建議修改後再上架。' : '';
  };
  setInterval(run, 800);
})();

// ===== AI 改寫文案：複製指令 → 同仁貼到 ChatGPT／Gemini／Claude → 貼回結果套用 =====
function aiPrompt() {
  const s = site || {};
  const v = $('oDesc').value, i = v.indexOf('\n——————');
  const draft = (i >= 0 ? v.slice(0, i) : v).trim();
  const facts = [['官網標題', s.title], ['售價', s.price && s.price + ' 萬'], ['社區', s.community], ['行政區', s.district], ['路名', s.road], ['型態', s.type], ['用途', s.use], ['格局', s.layout], ['建坪', s.areaTotal], ['主建物', s.areaMain && s.areaMain + ' 坪'], ['地坪', s.areaLand && s.areaLand + ' 坪'], ['屋齡', s.age && s.age + ' 年'], ['車位', s.parking], ['管理費', s.fee], ['座向', s.facing], ['生活機能', (s.life || []).join('、')], ['標籤', (s.tags || []).join('、')]]
    .filter(([, x]) => x).map(([k, x]) => `${k}：${x}`).join('\n');
  return `你是台灣房仲廣告文案編輯。請依下面的物件資料，改寫成能提高 591、樂屋網、Facebook Marketplace 搜尋曝光的高雄房屋廣告文案。

規則：
0. 這是一次獨立的任務：只寫下面這一筆物件，不要參考之前的對話、記憶或其他物件。
1. 只能使用下面提供的資料，不可以編造（資料沒寫的學區、捷運站、距離、裝潢、景觀、樓層都不能加）。
2. 標題與說明要自然放入買方常搜尋的字：行政區、路名、社區名稱、幾房、類型（電梯大樓／透天／公寓／店面）、車位、重點特色；不要重複堆疊關鍵字。
3. 不可以使用誇大或比較用語，例如：保證增值、穩賺、低於行情、最便宜、破盤、保證貸款、免頭期、全台最、第一。
4. 不寫門牌號碼、樓層、聯絡人、電話、公司資訊（系統會自動加在結尾）。
5. 說明約 400～800 字：開頭一段吸引人的重點介紹，接著用「■」條列物件資料與特色，再一段生活機能與適合的買方；不要用 Markdown 的 ** 或 #。
6. 全部使用繁體中文。

請完全依照下面的格式回覆，不要加其他文字：
【FB標題】（25～60 字）
【591標題】（6～30 字）
【說明】
（說明內文）

＝＝物件資料（物件編號 ${s.caseNo || ''}）＝＝
${facts}

＝＝官網特色原文＝＝
${s.feature || '（無）'}

＝＝目前的說明草稿（可參考，資料以上面為準）＝＝
${draft}`;
}
$('aiCopy').onclick = async () => {
  if (!site) { $('aiMsg').innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  try { await navigator.clipboard.writeText(aiPrompt()); } catch (e) { $('aiMsg').innerHTML = '<span class="err">複製失敗，請再按一次。</span>'; return; }
  $('aiMsg').textContent = '已複製指令，請在打開的 AI 對話框按 Ctrl+V 貼上送出。';
  window.open($('aiWho').value, '_blank');
  chrome.storage.local.set({ aiWho: $('aiWho').value });
};
chrome.storage.local.get('aiWho').then(x => { if (x.aiWho) $('aiWho').value = x.aiWho; });
function aiParse(t) {
  const clean = x => String(x || '').replace(/\*\*/g, '').replace(/^#+\s*/gm, '').replace(/^[（(].*?字[)）]\s*/, '').trim();
  const get = k => { const m = t.match(new RegExp('【' + k + '】[ \\t]*\\n?[ \\t]*([^\\n【]+)')); return m ? clean(m[1]) : ''; };   // 標題可能在同一行（Gemini）或下一行（ChatGPT）
  const dm = t.match(/【說明】[ \t]*\n?([\s\S]*)$/);
  return { fb: get('FB標題'), t591: get('591標題'), body: dm ? clean(dm[1]) : '' };
}
$('aiApply').onclick = () => applyAi($('aiOut').value, $('aiMsg'));
// 用 ChatGPT 自動改寫：在確認頁這邊控制（不交給背景程式，避免被 Chrome 暫停）
function gptSend(prompt) {   // 注入 ChatGPT 頁面：先清空輸入框（ChatGPT 會保留上次沒送出的草稿），再貼上這次的指令
  const ed = document.querySelector('.ProseMirror[contenteditable=true], #prompt-textarea');
  if (!ed) return { ok: false, why: 'noinput' };
  const norm = t => String(t || '').replace(/\s+/g, '');
  ed.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('delete', false, null);
  document.execCommand('insertText', false, prompt);
  const got = norm(ed.innerText), want = norm(prompt);
  if (got !== want) {   // 還有殘留文字：整個換掉再試一次
    ed.focus(); document.execCommand('selectAll', false, null); document.execCommand('insertText', false, prompt);
    if (norm(ed.innerText) !== want) return { ok: false, why: 'mismatch' };
  }
  return { ok: true };
}
function gptClick() {
  const b = document.querySelector('[data-testid=send-button], #composer-submit-button, button[aria-label="傳送"], button[aria-label="傳送提示"], button[aria-label*="Send"]');
  if (!b) return { ok: false }; b.click(); return { ok: true };
}
function gptRead() {   // 讀目前最新的回覆（含【FB標題】【說明】、不含我們的指令本身）
  const all = [...document.querySelectorAll('div')].filter(e => { const t = e.innerText || ''; return t.includes('【FB標題】') && t.includes('【說明】') && !t.includes('請完全依照下面的格式') && t.length < 8000; }).sort((a, b) => a.innerText.length - b.innerText.length);
  return { text: all.length ? all[0].innerText : '', busy: !!document.querySelector('[data-testid=stop-button]') };
}
const sleepMs = ms => new Promise(r => setTimeout(r, ms));
async function inTab(tabId, func, args) { const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args: args || [] }); return r && r.result; }
$('aiGpt').onclick = async () => {
  const msg = $('aiGptMsg');
  if (!site) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  $('aiGpt').disabled = true;
  const me0 = await chrome.tabs.getCurrent();
  let tab;
  try {
    msg.textContent = '開啟 ChatGPT 中…';
    tab = await chrome.tabs.create({ url: 'https://chatgpt.com/', active: true });
    let sent = false;
    for (let i = 0; i < 40 && !sent; i++) { await sleepMs(1000); try { const r = await inTab(tab.id, gptSend, [aiPrompt()]); sent = r && r.ok; } catch (e) {} }
    if (!sent) throw new Error('找不到 ChatGPT 的輸入框，請先在這個 Chrome 登入 ChatGPT 再按一次。');
    let clicked = false;
    for (let i = 0; i < 10 && !clicked; i++) { await sleepMs(800); try { const r = await inTab(tab.id, gptClick); clicked = r && r.ok; } catch (e) {} }
    if (!clicked) throw new Error('找不到 ChatGPT 的送出按鈕，請在 ChatGPT 自己按送出，再用下方「手動複製貼上」。');
    msg.textContent = '已送出，等 ChatGPT 回覆中（約 30～90 秒，請先不要關掉 ChatGPT 分頁）…';
    let last = '', stable = 0, text = '';
    for (let i = 0; i < 120; i++) {   // 最多 4 分鐘
      await sleepMs(2000);
      let r; try { r = await inTab(tab.id, gptRead); } catch (e) { continue; }
      const t = (r && r.text) || '';
      if (t && t === last && t.length > 60) stable++; else stable = 0;
      last = t;
      // 文字連續 6 秒沒變就算完成；ChatGPT 的「停止」鈕還在時多等一下（最多 12 秒）
      if (stable >= 3 && (!r.busy || stable >= 6)) { text = t; break; }
      if (t) msg.textContent = `ChatGPT 回覆中…（已收到 ${t.length} 字）`;
    }
    if (!text && last) text = last;
    const other = (text.match(/[A-Z]{2}\d{8}/g) || []).filter(x => x !== site.caseNo);
    if (other.length) throw new Error(`ChatGPT 的回覆提到別的物件編號（${other[0]}），可能混到上一筆資料。請再按一次「用 ChatGPT 自動改寫」。`);
    if (!text) throw new Error('沒有取得 ChatGPT 的回覆。可以到 ChatGPT 分頁看一下，再用下方「手動複製貼上」。');
    $('aiOut').value = text;
    if (me0) await chrome.tabs.update(me0.id, { active: true });
    await applyAi(text, msg);
  } catch (e) {
    msg.innerHTML = '<span class="err">' + (e.message || e) + '</span>';
    if (me0) chrome.tabs.update(me0.id, { active: true }).catch(() => {});
  }
  $('aiGpt').disabled = false;
};
async function applyAi(text, msgEl) {
  const r = aiParse(text);
  if (!r.body) { msgEl.innerHTML = '<span class="err">找不到【說明】，請把 AI 的回覆整段貼上（要有【FB標題】【591標題】【說明】）。</span>'; return; }
  if (r.fb) $('oTitle').value = r.fb.slice(0, 70);
  $('oDesc').value = r.body + '\n' + footer(cfg());
  let t591 = r.t591.replace(/\s+/g, ' ').trim();
  if (t591.length > 30) t591 = t591.slice(0, 30);
  await chrome.storage.local.set({ aiCopy: { caseNo: (site && site.caseNo) || '', title591: t591.length >= 6 ? t591 : '', body: r.body, use: $('aiAll').checked, at: Date.now() } });
  msgEl.innerHTML = '<span class="ok">已套用到上面的標題與說明' + ($('aiAll').checked ? '，樂屋網、591 也會使用這份文案' : '') + '。請再檢查一次內容。</span>';
  chrome.runtime.sendMessage({ type: 'log', what: 'AI改寫文案', title: (site && site.title) || '', caseNo: (site && site.caseNo) || '' });
}
$('aiAll').onchange = async () => { const { aiCopy } = await chrome.storage.local.get('aiCopy'); if (aiCopy) { aiCopy.use = $('aiAll').checked; chrome.storage.local.set({ aiCopy }); } };

// ===== 8 帶看介紹單 =====
$('btnFlyer').onclick = async () => {
  const msg = $('msgFlyer');
  if (!site) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  $('btnFlyer').disabled = true;
  try {
    const sel = photos.filter(p => p.sel).slice(0, 7);
    if (sel.length) {
      const out = [];
      for (let i = 0; i < sel.length; i++) { msg.textContent = `處理照片 ${i + 1} / ${sel.length}…`; out.push(await shrink(sel[i].f, 1400)); }
      await chrome.storage.local.set({ flyerPhotos: out });
    } else await chrome.storage.local.remove('flyerPhotos');
    msg.textContent = '已開啟介紹單（新分頁）。';
    chrome.tabs.create({ url: chrome.runtime.getURL('flyer.html') });
  } catch (e) { msg.innerHTML = '<span class="err">' + (e.message || e) + '</span>'; }
  $('btnFlyer').disabled = false;
};

// ===== 9 適合這筆物件的買方 =====
function lineMsg(b, s, p) {
  const body = ((() => { const v = $('oDesc').value, i = v.indexOf('\n——————'); return (i >= 0 ? v.slice(0, i) : v); })()).split('\n').map(x => x.trim()).filter(x => x && !/^【/.test(x) && !/^■/.test(x)).slice(0, 2).join(' ');
  const L = [`${b.name}您好，我是台灣房屋澄果團隊的${p.name}。有一筆符合您需求的物件想推薦給您：`, `【${s.title}】`];
  if (s.price) L.push(`・開價：${s.price} 萬`);
  L.push(`・位置：高雄市${s.district || ''}${s.road || ''}${s.community ? `（${s.community}）` : ''}`);
  if (s.layout || s.areaTotal) L.push(`・${[s.layout, s.areaTotal && '建坪 ' + s.areaTotal].filter(Boolean).join('｜')}`);
  if (s.parking) L.push(`・車位：${s.parking}`);
  if (body) L.push(`・重點：${body.slice(0, 80)}`);
  if (s.url) L.push(`更多照片：${s.url.split('?')[0]}`);
  L.push(`有興趣歡迎跟我約時間看屋！${p.phone ? '　' + p.phone : ''}`);
  return L.join('\n');
}
async function renderMatches() {
  const box = $('matchList');
  if (!site) { box.textContent = '讀取官網物件後會自動比對。'; return; }
  const r = await chrome.runtime.sendMessage({ type: 'matchData' });
  if (!r || !r.ok) { box.innerHTML = '<span class="err">' + ((r && r.error) || '比對失敗。') + '</span>'; return; }
  if (!r.total) { box.innerHTML = '還沒有登記買方需求。到 <b>k7.com.tw/listing</b> 的「我的買方」新增後，這裡就會自動比對。'; return; }
  if (!r.matches.length) { box.textContent = `已比對 ${r.total} 位買方，這筆物件沒有符合條件的人。`; return; }
  box.innerHTML = '';
  const head = document.createElement('p'); head.className = 'hint'; head.style.margin = '0 0 8px'; head.textContent = `已比對 ${r.total} 位買方，${r.matches.length} 位符合：`; box.appendChild(head);
  for (const b of r.matches) {
    const row = document.createElement('div'); row.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:8px 0;border-top:1px solid var(--line)';
    const n = document.createElement('b'); n.textContent = b.name; n.style.color = 'var(--ink)';
    const w = document.createElement('span'); w.textContent = [...b.why.map(x => '✓ ' + x), ...b.warn.map(x => '⚠ ' + x)].join('　'); w.style.cssText = 'font-size:14px;color:var(--mute);flex:1';
    const btn = document.createElement('button'); btn.textContent = '複製 LINE 訊息'; btn.style.cssText = 'font:inherit;font-size:14px;padding:4px 12px';
    btn.onclick = async () => { await navigator.clipboard.writeText(lineMsg(b, site, me || {})); btn.textContent = '已複製'; setTimeout(() => btn.textContent = '複製 LINE 訊息', 1500); };
    row.append(n, w, btn); box.appendChild(row);
  }
}
setTimeout(() => { renderMatches().catch(() => {}); }, 1500);
setTimeout(() => { if (!site) return; const t = $("matchList").textContent; if (/讀取官網/.test(t)) renderMatches().catch(() => {}); }, 5000);
