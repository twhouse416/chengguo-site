const $ = id => document.getElementById(id);
const MAXP = 10;
const SKIP = /評估|分析|謄本|產調|回報|建議書|配案/;
const CSNAME = /(^|[^a-z])cs([^a-z]|$)|case\s*stud|委託|資料表|物件表|銷售表/i;
let site = null, photos = [], me = null, sitePhotos = null, folderPhotos = [];

function footer(c) {
  const contact = [c.name && `聯絡人：${c.name}`, c.phone && `電話：${c.phone}`, c.line && `LINE：${c.line}`, c.lic && `營業員證號：${c.lic}`].filter(Boolean).join('｜');
  return ['', '——————', '台灣房屋 澄果團隊（澄果資產有限公司）', contact, '店址：高雄市鼓山區青海路416號｜店電：07-9766977', '物件資訊以現況及產權登記資料為準', '經紀人：邱秀琴(109)屏縣字第000147號'].filter((x, i) => i === 0 || x).join('\n');
}
const cfg = () => me || {};

const body = (s, price) => cgBody(s, price);

function refreshFooter() {
  const v = $('oDesc').value, i = v.indexOf('\n——————');
  $('oDesc').value = (i >= 0 ? v.slice(0, i) : v).replace(/\s+$/, '') + '\n' + footer(cfg());
}

function render() {
  const s = site;
  $('src').textContent = `官網物件編號 ${s.caseNo || '—'}　讀取時間 ${new Date(s.readAt).toLocaleString('zh-TW')}`;
  const rows = [['官網標題', s.title], ['售價', s.price && s.price + ' 萬'], ['社區', s.community], ['位置', `${s.district}${s.road}`], ['型態', s.type], ['用途', s.use], ['格局', s.layout], ['建坪', s.areaTotal], ['主建物', s.areaMain && s.areaMain + ' 坪'], ['主＋陽', s.areaMainBalcony && s.areaMainBalcony + ' 坪'], ['地坪', s.areaLand && s.areaLand + ' 坪'], ['屋齡', s.age && s.age + ' 年'], ['車位', s.parking], ['管理費', s.fee], ['座向', s.facing], ['特色', (s.tags || []).join('、')]];
  $('kv').replaceChildren(...rows.flatMap(([k, v]) => { const a = document.createElement('span'); a.textContent = k; const b = document.createElement('span'); b.textContent = v || '—'; return [a, b]; }));
  let t = [s.district, s.title, s.price && s.price + '萬'].filter(Boolean).join(' ');
  $('oTitle').value = t.length > 70 ? t.slice(0, 70) : t;
  $('oPrice').value = s.price || '';
  $('oDesc').value = body(s, s.price) + '\n' + footer(cfg());
}

/* 照片 */
const rank = n => /^\d+/.test(n) ? 1 : /格局/.test(n) ? 2 : /公設/.test(n) ? 3 : 4;
$('pickDir').onchange = e => {
  folderPhotos.forEach(p => URL.revokeObjectURL(p.url));
  photos = folderPhotos = [...e.target.files]
    .filter(f => (f.webkitRelativePath || f.name).split('/').length <= 2)
    .filter(f => /\.(jpe?g|png|webp)$/i.test(f.name) && !SKIP.test(f.name) && !CSNAME.test(f.name.replace(/\.[^.]+$/, '')))
    .map(f => ({ f, name: f.name, sel: false, url: URL.createObjectURL(f) }))
    .sort((a, b) => rank(a.name) - rank(b.name) || a.name.localeCompare(b.name, 'zh-Hant', { numeric: true }));
  let k = 0; for (const p of photos) { p.sel = !/配置/.test(p.name) && k < MAXP; if (p.sel) k++; }
  renderPhotos();
};
function renderPhotos() {
  let k = 0;
  $('photos').innerHTML = '';
  photos.forEach((p, i) => {
    const d = document.createElement('div'); d.className = 'ph' + (p.sel ? ' sel' : '');
    if (p.sel) { const n = document.createElement('span'); n.className = 'n'; n.textContent = ++k; d.appendChild(n); }
    const im = document.createElement('img'); im.src = p.url; im.alt = p.name; im.dataset.i = i; d.appendChild(im);
    const bar = document.createElement('div'); bar.className = 'bar';
    const l = document.createElement('button'); l.textContent = '◀'; l.dataset.mv = i; l.dataset.d = -1;
    const nm = document.createElement('span'); nm.textContent = p.name;
    const r = document.createElement('button'); r.textContent = '▶'; r.dataset.mv = i; r.dataset.d = 1;
    bar.append(l, nm, r); d.appendChild(bar); $('photos').appendChild(d);
  });
  $('phCount').textContent = photos.length ? `已選 ${k} / ${MAXP} 張（共 ${photos.length} 張）` : '';
}
$('photos').onclick = e => {
  const im = e.target.closest('img');
  if (im) { const p = photos[+im.dataset.i]; if (!p.sel && photos.filter(x => x.sel).length >= MAXP) { $('msg').textContent = `最多 ${MAXP} 張，請先取消一張`; return; } p.sel = !p.sel; renderPhotos(); return; }
  const b = e.target.closest('[data-mv]');
  if (b) { const i = +b.dataset.mv, j = i + +b.dataset.d; if (j < 0 || j >= photos.length) return; [photos[i], photos[j]] = [photos[j], photos[i]]; renderPhotos(); }
};

async function loadSitePhotos() {
  if (sitePhotos) return sitePhotos;
  const list = (site && site.photos || []).slice(0, 15);
  const out = [];
  for (let i = 0; i < list.length; i++) {
    $('srcHint').textContent = `下載官網照片 ${i + 1} / ${list.length}…`;
    try {
      const r = await fetch(list[i], { credentials: 'omit' });
      if (!r.ok) continue;
      const b = await r.blob();
      if (!/^image\//.test(b.type) || b.size < 8000) continue;     // 太小的多半是圖示
      out.push({ f: b, name: `官網照片 ${String(out.length + 1).padStart(2, '0')}`, sel: false, url: URL.createObjectURL(b) });
    } catch (e) {}
  }
  out.forEach((p, i) => p.sel = i < MAXP);
  return (sitePhotos = out);
}
async function useSource(src) {
  $('folderRow').hidden = src !== 'folder';
  if (src === 'site') {
    $('srcSite').checked = true;
    const l = await loadSitePhotos();
    if (!l.length) {
      $('srcHint').innerHTML = '<span class="err">官網照片抓不到或下載失敗，已改用「從物件資料夾選」。</span>';
      $('srcFolder').checked = true; $('folderRow').hidden = false; photos = folderPhotos; renderPhotos(); return;
    }
    $('srcHint').textContent = `已從官網取得 ${l.length} 張，預設選前 ${Math.min(MAXP, l.length)} 張。請確認是這筆物件的照片，可點選取消或調整順序。`;
    photos = l;
  } else {
    $('srcFolder').checked = true;
    $('srcHint').textContent = '選物件資料夾。A 開頭的子資料夾、CS 表與配置圖不會選入。';
    photos = folderPhotos;
  }
  renderPhotos();
}
$('srcSite').onchange = () => useSource('site');
$('srcFolder').onchange = () => useSource('folder');

async function shrink(file, max = 1600) {
  const bmp = await createImageBitmap(file);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 });
  return new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(out); });
}

$('btnGo').onclick = async () => {
  const msg = $('msg');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認，無法上架。</span>'; return; }
  const price = parseFloat($('oPrice').value);
  if (!$('oTitle').value.trim() || !isFinite(price)) { msg.innerHTML = '<span class="err">標題或價格是空的。</span>'; return; }
  const sel = photos.filter(p => p.sel);
  if (!sel.length) { msg.innerHTML = '<span class="err">請先選照片（官網照片或物件資料夾）。</span>'; return; }
  refreshFooter();
  $('btnGo').disabled = true;
  try {
    const out = [];
    for (let i = 0; i < sel.length; i++) { msg.textContent = `處理照片 ${i + 1} / ${sel.length}…`; out.push(await shrink(sel[i].f)); }
    const job = { title: $('oTitle').value.trim(), price: String(Math.round(price * 10000)), description: $('oDesc').value, photos: out, caseNo: (site && site.caseNo) || '', url: (site && site.url) || '', at: Date.now() };
    await chrome.storage.local.set({ job });
    const mode = curMode();
    const sch = !$('schOn').checked ? null : mode === 'remind'
      ? { mode, renewDays: +$('renewDays').value || 7, relistDays: +$('relistDays').value || 14 }
      : { mode, renewDays: 0, relistDays: +$('autoDays').value || 7 };
    chrome.storage.local.set({ schedDefaults: { renewDays: +$('renewDays').value || 7, relistDays: +$('relistDays').value || 14, mode, autoDays: +$('autoDays').value || 7 } });
    const res = await chrome.runtime.sendMessage({ type: 'start', schedule: sch });
    if (res && res.error) throw new Error(res.error);
    setTimeout(renderSched, 1500);
    msg.textContent = '已開啟手機模式視窗，正在自動填寫。完成後請檢查並自己按「發佈」。';
  } catch (e) { msg.innerHTML = '<span class="err">發生錯誤：' + (e.message || e) + '</span>'; }
  $('btnGo').disabled = false;
};

$('btnRakuya').onclick = async () => {
  const msg = $('msgR');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認。</span>'; return; }
  if (!site || !site.url) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  $('btnRakuya').disabled = true; msg.textContent = '開啟樂屋網刊登頁中…';
  const res = await chrome.runtime.sendMessage({ type: 'rakuya' });
  $('btnRakuya').disabled = false;
  msg.innerHTML = res && res.error ? '<span class="err">' + res.error + '</span>' : '已開啟樂屋網（新分頁），頁面上方會顯示填寫進度與需要確認的地方。';
};

$('btn591').onclick = async () => {
  const msg = $('msg591');
  if (!me) { msg.innerHTML = '<span class="err">尚未通過身分確認。</span>'; return; }
  if (!site || !site.url) { msg.innerHTML = '<span class="err">還沒有讀取官網物件。</span>'; return; }
  const pick = (document.querySelector('input[name=p591]:checked') || {}).value === 'pick';
  const sel = photos.filter(p => p.sel);
  if (pick && !sel.length) { msg.innerHTML = '<span class="err">請先在上方選照片，或改選「官網全部照片」。</span>'; return; }
  $('btn591').disabled = true;
  if (pick) {   // 用同仁選好的照片與順序
    const out = [];
    for (let i = 0; i < sel.length; i++) { msg.textContent = `處理照片 ${i + 1} / ${sel.length}…`; out.push(await shrink(sel[i].f)); }
    await chrome.storage.local.set({ f591Photos: out });
  } else await chrome.storage.local.remove('f591Photos');
  msg.textContent = '準備照片並開啟 591 中，約 10～30 秒…';
  const res = await chrome.runtime.sendMessage({ type: 'f591' });
  $('btn591').disabled = false;
  msg.innerHTML = res && res.error ? '<span class="err">' + res.error + '</span>' : '已開啟 591（新分頁），頁面上方會顯示填寫進度與需要確認的地方。';
};

// 兩段式確認（擴充功能頁不使用 confirm 對話框）：第一次按顯示警告，3 秒內再按才執行
const curMode = () => (document.querySelector('input[name=mode]:checked') || {}).value || 'remind';
const MODE_NAME = { remind: '提醒', semi: '半自動', auto: '全自動' };
function confirmBox(btn, warn) {
  if (btn.dataset.armed === '1') { btn.dataset.armed = ''; return true; }
  btn.dataset.armed = '1'; const old = btn.textContent; btn.textContent = '再按一次確認'; $('msg').textContent = warn;
  setTimeout(() => { if (btn.dataset.armed === '1') { btn.dataset.armed = ''; btn.textContent = old; } }, 4000);
  return false;
}
async function renderSched() {
  const { sched = [] } = await chrome.storage.local.get('sched');
  const box = $('schedList'); box.innerHTML = '';
  if (!sched.length) { box.textContent = '目前沒有排程。'; return; }
  const fmt = t => new Date(t).toLocaleString('zh-TW', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  for (const e of sched) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;flex-wrap:wrap;gap:10px;align-items:center;border-top:1px solid var(--line);padding:10px 0;color:var(--ink);font-size:15px';
    const t = document.createElement('span'); t.style.flex = '1 1 260px';
    const mode = e.mode || (e.auto ? 'auto' : 'remind');
    t.textContent = mode !== 'remind'
      ? `${e.title}　上架 ${fmt(e.listedAt)}｜${MODE_NAME[mode]}：每 ${e.relistDays} 天，下次 ${fmt(e.listedAt + e.relistDays * 864e5)}`
      : `${e.title}　上架 ${fmt(e.listedAt)}｜更新 ${fmt(e.listedAt + e.renewDays * 864e5)}｜重新上架 ${fmt(e.listedAt + e.relistDays * 864e5)}`;
    const au = document.createElement('span'); au.style.cssText = 'display:flex;gap:6px;align-items:center';
    const css = 'font:inherit;font-size:14px;padding:4px 6px;border:1px solid var(--line);border-radius:3px';
    const ms = document.createElement('select'); ms.style.cssText = css;
    for (const [v, n] of Object.entries(MODE_NAME)) { const o = document.createElement('option'); o.value = v; o.textContent = n; ms.appendChild(o); }
    ms.value = mode;
    const sel = document.createElement('select'); sel.style.cssText = css;
    for (let d = 1; d <= 7; d++) { const o = document.createElement('option'); o.value = d; o.textContent = `每 ${d} 天`; sel.appendChild(o); }
    sel.value = mode === 'remind' ? 7 : Math.min(7, Math.max(1, e.relistDays)); sel.hidden = mode === 'remind';
    const save = async () => { await chrome.runtime.sendMessage({ type: 'setMode', id: e.id, mode: ms.value, days: +sel.value }); renderSched(); };
    ms.onchange = save; sel.onchange = save;
    au.append(ms, sel);
    const now = document.createElement('button'); now.textContent = mode === 'auto' ? '立即執行一次（測試）' : '立即刪舊並重新上架';
    now.onclick = async () => {
      if (!confirmBox(now, `會立刻刪除「${e.title}」的舊刊登並重新上架${mode === 'auto' ? '（自動發佈）' : '（發佈由你按）'}，刪除後無法復原。再按一次確認執行。`)) return;
      await chrome.runtime.sendMessage({ type: 'runNow', id: e.id }); now.textContent = '執行中，請看開啟的視窗…'; now.disabled = true;
      setTimeout(renderSched, 20000);
    };
    const b = document.createElement('button'); b.textContent = '只停止排程'; b.title = '不刪除 Facebook 上的刊登';
    b.onclick = async () => { await chrome.runtime.sendMessage({ type: 'cancelSched', id: e.id }); renderSched(); };
    const td = document.createElement('button'); td.textContent = '下架並刪除'; td.style.cssText = 'color:#b42318;border-color:#f0b4ae';
    td.onclick = async () => {
      if (!confirmBox(td, `會從 Facebook 刪除「${e.title}」的刊登（同標題全部）並停止排程，刪除後無法復原。再按一次確認。`)) return;
      await chrome.runtime.sendMessage({ type: 'takedown', id: e.id }); td.textContent = '下架中，請看開啟的視窗…'; td.disabled = true;
      setTimeout(renderSched, 20000);
    };
    row.append(t, au, now, td, b); box.appendChild(row);
  }
}

(async () => {
  renderSched();
  const st = await chrome.storage.local.get(['site', 'schedDefaults']);
  const d = st.schedDefaults || {};
  $('renewDays').value = d.renewDays || 7; $('relistDays').value = d.relistDays || 14; $('autoDays').value = d.autoDays || 7;
  const m0 = d.mode || (d.auto ? 'auto' : 'remind');
  document.querySelector(`input[name=mode][value=${m0}]`).checked = true;
  const syncMode = () => { const m = curMode(); $('autoRow').hidden = m === 'remind'; $('manualRow').hidden = m !== 'remind'; };
  document.querySelectorAll('input[name=mode]').forEach(r => r.onchange = syncMode); syncMode();
  const who = await chrome.runtime.sendMessage({ type: 'whoami' });
  if (who && who.ok) {
    me = who.profile;
    const rows = [['Google 帳號', me.email], ['聯絡人', me.name], ['電話', me.phone], ['LINE', me.line || '—'], ['營業員證號', me.lic]];
    $('me').replaceChildren(...rows.flatMap(([k, v]) => { const a = document.createElement('span'); a.textContent = k; const b = document.createElement('span'); b.textContent = v || '—'; return [a, b]; }));
  } else {
    $('me').innerHTML = '';
    const e = document.createElement('span'); e.className = 'err'; e.style.gridColumn = '1/-1'; e.textContent = (who && who.error) || '無法確認身分。'; $('me').appendChild(e);
    $('btnGo').disabled = true;
  }
  site = st.site;
  if (!site) { $('src').textContent = '還沒有讀取官網物件。請先在 Chrome 打開台灣房屋官網的物件頁，再按「澄果上架」→「讀取這個官網物件」。'; return; }
  render();
  useSource(site.photos && site.photos.length ? 'site' : 'folder');
})();

// 廣告用語檢查：標題、說明有容易被認定為不實或誇大的字眼就用黃色提醒（只提醒，不擋上架）
(() => {
  let last = null;
  const run = () => {
    const t = document.getElementById('oTitle'), d = document.getElementById('oDesc'), box = document.getElementById('adWarn');
    if (!t || !d || !box || typeof cgAdRisk !== 'function') return;
    const v = t.value + '\n' + d.value; if (v === last) return; last = v;
    const hits = cgAdRisk(v);
    box.hidden = !hits.length;
    box.textContent = hits.length ? '⚠ 廣告用語提醒：' + hits.map(h => `「${h.word}」（${h.why}）`).join('、') + '。容易被認定為不實或誇大廣告，建議修改後再上架。' : '';
  };
  setInterval(run, 800);
})();
