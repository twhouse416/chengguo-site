// 共用：依官網資料組出說明（確認頁與全自動重新上架都用這一份）
function cgBody(s, price) {
  const basics = [
    price && `■ 售價：${price} 萬`,
    s.community && `■ 社區：${s.community}`,
    (s.district || s.road) && `■ 位置：高雄市${s.district}${s.road}`,
    s.type && `■ 型態：${s.type}`,
    s.layout && `■ 格局：${s.layout}`,
    s.areaTotal && `■ 建坪：${s.areaTotal.replace(/\s*\(\s*/, '（').replace(/\s*\)/, '）')}`,
    s.areaMain && `■ 主建物：${s.areaMain} 坪`,
    s.areaMainBalcony && `■ 主建物＋陽台：${s.areaMainBalcony} 坪`,
    s.areaLand && `■ 地坪：${s.areaLand} 坪`,
    s.age && `■ 屋齡：${s.age} 年`,
    s.parking && `■ 車位：${s.parking}`,
    s.fee && `■ 管理費：${s.fee}`,
    s.facing && `■ 座向：${s.facing}`
  ].filter(Boolean);
  const tags = (s.tags || []).map(t => '✔ ' + t);
  return ['【物件資料】\n' + basics.join('\n'), tags.length && '【特色】\n' + tags.join('\n')].filter(Boolean).join('\n\n');
}