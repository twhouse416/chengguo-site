// 澄果符號盤：分類好的符號、表情、分隔線與標題框，點一下插入到游標位置。
// 用在三個地方：擴充功能上架頁的 FB 說明欄（#oDesc）、樂屋網刊登頁、591 刊登頁。
// 只插入一般文字符號，不改字體或顏色（Facebook 只吃純文字；樂屋網、591 的粗體與顏色請用它們自己的編輯工具列）。
(() => {
  if (window.__cgPalette) return; window.__cgPalette = true;

  const CATS = [
    { name: '⭐ 星星', items: '★ ☆ ⭐ 🌟 ✨ ✦ ✧ ✪ ❖ ❋ ✿ ❀ 💫'.split(' ') },
    { name: '■ 項目符號', items: '■ □ ● ○ ◆ ◇ ▲ ▶ ► ➤ ➜ ✔ ✅ ☑ 👉 ▪ ・'.split(' ') },
    { name: '【】標題框', wrap: true, items: ['【】', '〖〗', '『』', '「」', '《》', '［］', '〔〕', '✦ ✦', '★ ★'] },
    { name: '━ 分隔線', line: true, items: ['━━━━━━━━━━━━', '────────────', '✦━━━━━✦━━━━━✦', '★☆★☆★☆★☆★☆', '＝＝＝＝＝＝＝＝', '⋯⋯⋯⋯⋯⋯', '▼▼▼▼▼▼▼▼', '◆◇◆◇◆◇◆◇'] },
    { name: '🏠 房屋', items: '🏠 🏡 🏢 🏘️ 🛋️ 🛏️ 🛁 🚿 🍳 🌅 🌇 🪟 🔑 📐 🧱 🛗'.split(' ') },
    { name: '🚇 交通', items: '🚇 🚉 🚈 🚌 🚗 🅿️ 🛣️ 🚲 🛵 ✈️ 🚶'.split(' ') },
    { name: '🏫 生活機能', items: '🏫 🎓 🏥 💊 🛒 🏪 🍽️ ☕ 🌳 🏞️ 🏛️ 🏦 🎡 🏋️'.split(' ') },
    { name: '📞 聯絡', items: '📞 ☎️ 📱 💬 📍 🗺️ ⏰ 📩 🙋 🤝'.split(' ') },
    { name: '🔥 強調', items: '🔥 💎 🎉 💰 💯 👍 ⚡ ❗ ‼️ 🆕 🔝 🏆 ❤️ 🌈'.split(' ') },
    { name: '① 數字', items: '① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ❶ ❷ ❸ ❹ ❺ 1️⃣ 2️⃣ 3️⃣ 4️⃣ 5️⃣'.split(' ') }
  ];

  // ---- 找出要插入的編輯區 ----
  const host = location.hostname;
  const PANEL = !!document.getElementById('oDesc');
  let last = null;                                   // 最後一次有游標的編輯區
  const isEditor = el => el && (el.tagName === 'TEXTAREA' || (el.isContentEditable && el.closest('.note-editable,.ProseMirror,[contenteditable=true]')));
  document.addEventListener('focusin', e => { const t = e.target.closest ? (e.target.closest('textarea,.note-editable,.ProseMirror') || e.target) : e.target; if (isEditor(t) && !t.closest('#cg-pal')) last = t; }, true);
  const defaultEditor = () => PANEL ? document.getElementById('oDesc')
    : /rakuya/.test(host) ? document.querySelector('.note-editable')
    : /591/.test(host) ? document.querySelector('.ProseMirror') : null;
  const target = () => (last && document.contains(last)) ? last : defaultEditor();

  function insert(text, opts = {}) {
    const el = target();
    if (!el) { toast('找不到說明欄，請先點一下說明欄再選符號。'); return; }
    if (el.tagName === 'TEXTAREA') {
      el.focus();
      const s = el.selectionStart, e = el.selectionEnd, sel = el.value.slice(s, e);
      let ins = text;
      if (opts.wrap) ins = wrapText(text, sel);
      else if (opts.bullet && sel.includes('\n')) ins = sel.split('\n').map(l => l.trim() ? text + ' ' + l.replace(/^[■□●○◆◇▲▶►➤➜✔✅☑👉▪・★☆⭐✦✧]\s*/u, '') : l).join('\n');
      else if (opts.line) ins = (s > 0 && el.value[s - 1] !== '\n' ? '\n' : '') + text + '\n';
      el.setRangeText(ins, s, e, 'end');
      el.dispatchEvent(new Event('input', { bubbles: true }));
      return;
    }
    // 樂屋網（summernote）、591（ProseMirror）：在原本的游標位置輸入
    el.focus();
    const sel = window.getSelection();
    if (!sel.rangeCount || !el.contains(sel.anchorNode)) { sel.selectAllChildren(el); sel.collapseToEnd(); }
    const picked = sel.toString();
    let ins = opts.wrap ? wrapText(text, picked) : opts.line ? '\n' + text + '\n' : text;
    document.execCommand('insertText', false, ins);
  }
  function wrapText(pair, sel) {
    if (pair.includes(' ')) { const [a, b] = pair.split(' '); return `${a} ${sel || '標題'} ${b}`; }
    const a = [...pair][0], b = [...pair].slice(1).join('');
    return a + (sel || '標題') + b;
  }

  // ---- 介面 ----
  const css = `
#cg-pal{font:14px/1.5 "Microsoft JhengHei","Noto Sans TC",system-ui,sans-serif;color:#151513;box-sizing:border-box}
#cg-pal *{box-sizing:border-box}
#cg-pal .cg-tabs{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px}
#cg-pal .cg-tab{border:1px solid #dcdcd6;background:#fff;border-radius:3px;padding:3px 9px;font:inherit;font-size:13px;cursor:pointer;color:#151513}
#cg-pal .cg-tab.on{background:#151513;color:#fff;border-color:#151513}
#cg-pal .cg-items{display:flex;flex-wrap:wrap;gap:4px}
#cg-pal .cg-it{border:1px solid #e6e6e0;background:#fafaf8;border-radius:3px;min-width:34px;height:34px;padding:0 7px;font-size:18px;cursor:pointer;color:#151513;font-family:inherit}
#cg-pal .cg-it.txt{font-size:14px}
#cg-pal .cg-it:hover{background:#FCEFE3;border-color:#FD7305}
#cg-pal .cg-hint{font-size:12px;color:#62625c;margin-top:6px}
#cg-fab{position:fixed;right:20px;bottom:90px;z-index:2147483646;background:#FD7305;color:#151513;border:0;border-radius:24px;padding:10px 16px;font:700 15px "Microsoft JhengHei","Noto Sans TC",sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.25);cursor:pointer}
#cg-pal.float{position:fixed;right:20px;bottom:140px;z-index:2147483646;width:380px;max-height:60vh;overflow:auto;background:#fff;border:1px solid #dcdcd6;border-radius:6px;padding:12px;box-shadow:0 6px 24px rgba(0,0,0,.2)}
#cg-pal.inline{margin:6px 0 4px;padding:8px;border:1px solid #dcdcd6;border-radius:4px;background:#fff}
#cg-toast{position:fixed;left:50%;bottom:40px;transform:translateX(-50%);z-index:2147483647;background:#151513;color:#fff;padding:8px 14px;border-radius:4px;font:14px "Microsoft JhengHei",sans-serif}`;
  const st = document.createElement('style'); st.textContent = css; document.documentElement.appendChild(st);

  function toast(t) { let d = document.getElementById('cg-toast'); if (!d) { d = document.createElement('div'); d.id = 'cg-toast'; document.body.appendChild(d); } d.textContent = t; clearTimeout(d._t); d._t = setTimeout(() => d.remove(), 2500); }

  function build(mode) {
    const pal = document.createElement('div'); pal.id = 'cg-pal'; pal.className = mode;
    // 點符號盤時不要搶走編輯區的游標
    pal.addEventListener('mousedown', e => { if (e.target.closest('button')) e.preventDefault(); });
    const tabs = document.createElement('div'); tabs.className = 'cg-tabs';
    const items = document.createElement('div'); items.className = 'cg-items';
    const hint = document.createElement('div'); hint.className = 'cg-hint';
    let cur = 0;
    const draw = () => {
      tabs.replaceChildren(...CATS.map((c, i) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'cg-tab' + (i === cur ? ' on' : ''); b.textContent = c.name; b.onclick = () => { cur = i; draw(); }; return b; }));
      const c = CATS[cur];
      items.replaceChildren(...c.items.map(t => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'cg-it' + (t.length > 3 ? ' txt' : ''); b.textContent = t;
        b.title = c.wrap ? '把選取的文字框起來' : c.line ? '插入一整行' : '插入到游標位置';
        b.onclick = () => insert(t, { wrap: c.wrap, line: c.line, bullet: cur === 1 });
        return b;
      }));
      hint.textContent = c.wrap ? '先選取文字再按，會把文字框起來；沒選取會插入「標題」讓你改。'
        : c.line ? '會在游標處插入一整行分隔線。'
        : cur === 1 && PANEL ? '選取多行再按，每一行前面都會加上符號。'
        : '先點說明欄要插入的位置，再點符號。';
    };
    draw();
    pal.append(tabs, items, hint);
    return pal;
  }

  function mountPanel() {
    const ta = document.getElementById('oDesc'); if (!ta || document.getElementById('cg-pal')) return;
    ta.parentNode.insertBefore(build('inline'), ta);
  }
  function mountFloat() {
    if (document.getElementById('cg-fab')) return;
    const fab = document.createElement('button'); fab.id = 'cg-fab'; fab.type = 'button'; fab.textContent = '★ 澄果符號盤';
    fab.addEventListener('mousedown', e => e.preventDefault());
    let pal = null;
    fab.onclick = () => { if (pal) { pal.remove(); pal = null; fab.textContent = '★ 澄果符號盤'; return; } pal = build('float'); document.body.appendChild(pal); fab.textContent = '✕ 關閉符號盤'; };
    document.body.appendChild(fab);
  }

  if (PANEL) mountPanel();
  else {
    // 只在刊登頁有說明編輯器時才出現
    const tryMount = () => { if (defaultEditor()) { mountFloat(); return true; } return false; };
    if (!tryMount()) { const ob = new MutationObserver(() => { if (tryMount()) ob.disconnect(); }); ob.observe(document.documentElement, { childList: true, subtree: true }); setTimeout(() => ob.disconnect(), 120000); }
  }
})();
