const msg = document.getElementById('msg');
const say = (t, cls) => { msg.className = cls || ''; msg.textContent = t; };

async function shrink(blob, max = 1600) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * k), Math.round(bmp.height * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.86 });
  return new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(out); });
}

document.getElementById('pick').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    say('讀取上架包中…');
    const zip = await JSZip.loadAsync(file);
    const jf = zip.file('listing.json');
    if (!jf) throw new Error('這個檔案不是上架包（找不到 listing.json）。請從小幫手第 5 步重新下載。');
    const d = JSON.parse(await jf.async('string'));
    if (!d.title || !d.price) throw new Error('上架包缺少標題或價格，請回小幫手重新產生。');
    const names = (d.photos || []).slice(0, 10);
    const photos = [];
    for (let i = 0; i < names.length; i++) {
      say(`處理照片 ${i + 1} / ${names.length}…`);
      const f = zip.file(names[i]);
      if (f) photos.push(await shrink(await f.async('blob')));
    }
    const job = { title: d.title, price: String(d.price), description: d.description || '', photos, at: Date.now() };
    await chrome.storage.local.set({ job });
    const { schedDefaults } = await chrome.storage.local.get('schedDefaults');
    const sch = document.getElementById('zipSch').checked ? (schedDefaults || { renewDays: 7, relistDays: 14 }) : null;
    const res = await chrome.runtime.sendMessage({ type: 'start', schedule: sch });
    if (res && res.error) throw new Error(res.error);
    say(`已開啟手機模式視窗，正在自動填寫：\n${d.title}\n${photos.length} 張照片`, 'ok');
  } catch (err) {
    say(err.message || String(err), 'err');
  }
});

// 官網物件：貼上網址或物件編號
(async () => {
  const btn = document.getElementById('readSite'), box = document.getElementById('siteUrl');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && /twhg\.com\.tw\/buy\//i.test(tab.url || '')) box.value = tab.url;
  } catch (e) {}
  const norm = v => {
    v = v.trim();
    const id = (v.match(/([A-Z]{2}\d{6,})/i) || [])[1];
    if (/^https?:\/\/(www\.)?twhg\.com\.tw\/buy\//i.test(v)) return v.split('#')[0];
    return id ? `https://www.twhg.com.tw/buy/${id.toUpperCase()}` : '';
  };
  const go = async () => {
    const url = norm(box.value);
    if (!url) { say('請貼上台灣房屋官網的物件網址，例如 https://www.twhg.com.tw/buy/TE02565589，或輸入物件編號 TE02565589。', 'err'); return; }
    btn.disabled = true; say('讀取官網物件中，約需 5～15 秒…');
    const res = await chrome.runtime.sendMessage({ type: 'readUrl', url });
    btn.disabled = false;
    if (!res || res.error) say((res && res.error) || '讀取失敗，請再試一次。', 'err');
  };
  btn.onclick = go;
  box.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  box.focus();
})();

document.getElementById('manage').onclick = e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('panel.html#sched') }); };

// 顯示登入身分；未授權則停用所有按鈕
(async () => {
  const el = document.getElementById('whoami');
  const r = await chrome.runtime.sendMessage({ type: 'whoami' });
  if (r && r.ok) { el.className = 'ok'; el.textContent = `已登入：${r.profile.name}（${r.profile.email}）`; return; }
  el.className = 'err'; el.textContent = (r && r.error) || '無法確認身分。';
  document.querySelectorAll('button,input').forEach(x => x.disabled = true);
  document.querySelectorAll('label.btn').forEach(x => { x.style.opacity = .5; x.style.pointerEvents = 'none'; });
})();
