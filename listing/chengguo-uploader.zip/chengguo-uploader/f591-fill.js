// 591「刊登出售」自動填寫（在 user.591.com.tw 頁面的主程式環境執行）
// 第一步 f591Step1：依官網用途／類型點選「房屋法定用途 → 房屋現況 → 房屋型態」，進入填寫頁。
// 第二步 f591Fill：填寫資料、上傳照片、說明加上聯絡資料與團隊結尾。
// 不會按「保存資料，下一步」或付款——一律由同仁自己確認後按。

// ---- 對應規則（兩步共用，寫在函式裡面，因為注入頁面時只會帶函式本身） ----
async function f591Step1(d) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const own = e => [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
  const shown = e => e && getComputedStyle(e).display !== 'none' && e.getClientRects().length > 0;
  const findText = t => [...document.querySelectorAll('body *')].filter(e => own(e) === t && shown(e)).pop();
  const until = async (fn, ms = 12000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await sleep(250); } return null; };

  const use = String(d.site.use || ''), typ = String(d.site.type || '');
  const shop = /店面|店鋪|店舖/.test(use), office = /辦公|商辦|事務所/.test(use);
  const purpose = (shop || office) ? '商業用' : /住商/.test(use) ? '住商用' : '住家用';
  const kind = shop ? '店面' : office ? '辦公' : /套房/.test(typ) ? '套房' : '住宅';
  const shape = /華廈/.test(typ) ? '華廈' : /大樓|大廈|電梯/.test(typ) ? '電梯大樓' : /公寓/.test(typ) ? '公寓'
    : /透天/.test(typ) ? '透天厝' : /別墅/.test(typ) ? '別墅' : '電梯大樓';

  const sale = await until(() => findText('出售'));
  if (!sale) return { ok: false, error: '找不到 591 刊登頁的「出售」選項，可能是 591 改版，請通知管理者。' };
  sale.click(); await sleep(600);
  const p = await until(() => findText(purpose));
  if (!p) return { ok: false, error: `找不到法定用途「${purpose}」。` };
  p.click(); await sleep(900);
  const k = await until(() => findText(kind));
  if (!k) return { ok: false, error: `找不到房屋現況「${kind}」。` };
  k.click(); await sleep(1200);
  const s = await until(() => findText(shape), 4000);
  if (s) { s.click(); return { ok: true, purpose, kind, shape }; }
  if (shop) { const s2 = findText('店面（店鋪）') || findText('店面(店鋪)'); if (s2) { s2.click(); return { ok: true, purpose, kind, shape: '店面（店鋪）' }; } }
  // 部分現況（例如套房、店面）可能直接進入填寫頁，或型態清單不同
  return { ok: true, purpose, kind, shape: '', note: `房屋型態沒有「${shape}」可選` };
}

async function f591Fill(d) {
  const warn = [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const own = e => [...e.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
  const shown = e => e && getComputedStyle(e).display !== 'none' && e.getClientRects().length > 0;
  const until = async (fn, ms = 10000, step = 250) => { const t = Date.now(); while (Date.now() - t < ms) { try { const v = fn(); if (v) return v; } catch (e) {} await sleep(step); } return null; };
  const T = 'input:not([type=radio]):not([type=checkbox]):not([type=search]):not([type=file]):not([type=hidden])';
  const setv = (el, v) => {
    if (!el || v === '' || v == null) return false;
    el.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, String(v));
    ['input', 'change', 'blur'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
    return true;
  };
  const rowBy = t => $$('.ant-form-item').find(f => (f.querySelector('.ant-form-item-label')?.innerText || '').replace(/\s/g, '').startsWith(t));
  const choose = async (row, txt) => {   // 點 radio／checkbox
    const l = row && $$('label.ant-radio-wrapper,label.ant-checkbox-wrapper', row).find(x => x.innerText.trim() === txt);
    if (l && !/wrapper-checked/.test(l.className)) { (l.querySelector('input') || l).click(); await sleep(300); }
    return !!l;
  };
  const closeDrop = () => document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  async function antPick(sel, text) {      // Ant Design 下拉選單（清單是虛擬捲動，要邊捲邊找）
    if (!sel) return false;
    const cur = sel.querySelector('.ant-select-selection-item');
    if (cur && cur.textContent.trim() === text) return true;
    sel.querySelector('.ant-select-selector').dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    const dd = await until(() => $$('.ant-select-dropdown').filter(shown).pop(), 3000);
    if (!dd) return false;
    const holder = dd.querySelector('.rc-virtual-list-holder') || dd;
    holder.scrollTop = 0; await sleep(150);
    for (let i = 0; i < 80; i++) {
      const o = $$('.ant-select-item-option', dd).find(x => (x.getAttribute('title') || x.textContent).trim() === text);
      if (o) { o.click(); await sleep(600); return true; }
      const before = holder.scrollTop; holder.scrollTop += 160; holder.dispatchEvent(new Event('scroll')); await sleep(120);
      if (holder.scrollTop === before) break;
    }
    closeDrop(); return false;
  }
  function banner(kind, title, lines) {
    let b = document.getElementById('cg-banner');
    if (!b) { b = document.createElement('div'); b.id = 'cg-banner'; document.body.appendChild(b); }
    const bg = kind === 'ok' ? '#18794e' : kind === 'err' ? '#b42318' : '#151513';
    b.style.cssText = `position:fixed;left:0;right:0;top:0;z-index:2147483647;background:${bg};color:#fff;font:15px/1.6 "Microsoft JhengHei","Noto Sans TC",sans-serif;padding:10px 14px;box-shadow:0 2px 8px rgba(0,0,0,.3);max-height:45vh;overflow:auto`;
    b.innerHTML = '';
    const h = document.createElement('div'); h.style.fontWeight = '700'; h.textContent = '澄果上架｜' + title; b.appendChild(h);
    for (const l of lines || []) { const p = document.createElement('div'); p.textContent = l; if (/^⚠/.test(l)) p.style.cssText = 'background:#fff6cc;color:#151513;border-radius:3px;padding:2px 8px;margin-top:4px'; b.appendChild(p); }
    const x = document.createElement('button'); x.textContent = '關閉提示'; x.style.cssText = 'margin-top:6px;font:inherit;font-size:13px;padding:2px 10px;border:0;border-radius:3px;cursor:pointer';
    x.onclick = () => b.remove(); b.appendChild(x);
  }
  const mark = el => { if (el) { el.style.outline = '3px solid #b42318'; el.style.background = '#fff0ee'; } };
  const num = s => (String(s || '').replace(/,/g, '').match(/\d+(?:\.\d+)?/) || [''])[0];
  const s = d.site;

  try {
    banner('run', '正在自動填寫 591…', ['請先不要操作這個頁面，約 20～40 秒。']);
    await until(() => $('[data-position=address]'), 15000);
    if (!$('[data-position=address]')) throw new Error('找不到 591 填寫頁的地址欄，可能是 591 改版，請通知管理者。');

    // 1. 地址：縣市（進頁時的選擇視窗或第一個下拉）→ 區 → 街道
    const city = s.city || '高雄市';
    const cityEl = await until(() => [...document.querySelectorAll('body *')].filter(e => own(e) === city && shown(e) && e.closest('.ant-modal-wrap,.ant-modal')).pop(), 3000);
    const addr = $('[data-position=address]');
    if (cityEl) { cityEl.click(); await sleep(1500); }
    else await antPick($$('.ant-select', addr)[0], city);
    if (!await antPick($$('.ant-select', addr)[1], s.district)) warn.push(`⚠ 行政區「${s.district || '（空白）'}」沒有選到，請手動選擇。`);
    await sleep(800);
    let roadOk = false;
    if (s.road) {
      $$('.ant-select', addr)[2].querySelector('.ant-select-selector').dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      const box = await until(() => $$('input').find(i => i.placeholder === '請輸入街道名稱' && shown(i)), 3000);
      if (box) {
        setv(box, s.road); box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        const li = await until(() => $$('.street li').find(l => l.textContent.trim() === s.road), 4000);
        if (li) { li.click(); roadOk = true; await sleep(800); } else closeDrop();
      }
    }
    if (!roadOk) warn.push(`⚠ 街道「${s.road || '（空白）'}」沒有選到，請手動選擇。`);
    // 號：留空標紅，勾隱藏門號
    const addrInputs = $$(T, addr);
    const noInput = addrInputs.find(i => i.placeholder === '必填');
    mark(noInput);
    const hide = $$('label.ant-checkbox-wrapper', addr).find(l => l.innerText.includes('隱藏門號'));
    if (hide && !/wrapper-checked/.test(hide.className)) { (hide.querySelector('input') || hide).click(); await sleep(200); }
    warn.push('⚠ 門牌「號」請自己填（紅框）；已勾「隱藏門號」，前台不會顯示號碼。社區欄下方紅字「請先選擇社區所在縣市街道」填好號碼後就會消失。');

    // 2. 樓層：官網「10/28樓」；透天、整棟為 0
    const fm = String(s.floor || '').replace(/\s/g, '').match(/^(.+?)\/(\d+)/);
    const total = fm ? fm[2] : '';
    let floor = fm ? fm[1] : '';
    if (/透天|別墅/.test(s.type || '') || /~|～|整棟|全/.test(floor)) floor = '0';
    floor = floor.replace(/[~～至到]/g, '-').replace(/[^\d-]/g, '');
    const fItem = addr.closest('.ant-form-item').nextElementSibling;
    const multi = floor.match(/^(\d+)-(\d+)$/);
    if (multi && fItem) {   // 例如「1-2/27樓」：選「出售多層」，填最低、最高樓層
      await antPick($('.ant-select', fItem), '出售多層'); await sleep(500);
      const fl = $$(T, fItem);
      if (!(setv(fl[0], multi[1]) && setv(fl[1], multi[2]))) warn.push('⚠ 出售多層的樓層沒有填到，請手動填寫。');
    } else if (!setv(fItem && $(T, fItem), floor)) warn.push('⚠ 出售樓層沒有填到，請手動填寫。');
    if (!setv($(T, $('[data-position=total_floor]')), total)) warn.push('⚠ 總樓層沒有填到，請手動填寫。');

    // 3. 社區：點輸入框出現建議清單，選名稱完全相同的那一個
    const cRow = $('[data-position=community_name]');
    const name = String(s.community || '').trim();
    const norm = x => String(x).replace(/[\s　]/g, '').replace(/[（(].*?[)）]/g, '').replace(/[Ａ-Ｚａ-ｚ０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 65248)).replace(/(社區|大樓|大廈|華廈)$/, '').toLowerCase();
    const nm = it => (it.querySelector('span:not(.address)')?.textContent || '').trim();
    const ad = it => (it.querySelector('.address')?.textContent || '');
    const pick = (items, n) => {   // 名稱相符的建議中，優先選地址在同一條路的
      const exact = items.filter(it => nm(it) === n || norm(nm(it)) === norm(n));
      const fz = norm(n).length >= 3 ? items.filter(it => { const t = norm(nm(it)); return t.length >= 3 && (t.includes(norm(n)) || norm(n).includes(t)); }) : [];
      const best = l => l.find(it => s.road && ad(it).includes(s.road)) || l[0];
      return exact.length ? { hit: best(exact), fuzzy: false } : fz.length ? { hit: best(fz), fuzzy: true } : {};
    };
    const noComm = /透天|別墅|公寓|店面|店鋪|店舖/.test(s.type || '') && !/大樓|大廈|華廈/.test(s.type || '');
    if (name && cRow) {
      const ci = $('input', cRow);
      // 先不打字點一下：591 會依街道列出「你找的可能是」
      ci.click(); ci.focus(); await sleep(1200);
      let dd = $$('.ant-dropdown').filter(shown).pop();
      let r = dd ? pick($$('.select-drop-item', dd), name) : {};
      if (!r.hit) {   // 再用名稱搜尋
        setv(ci, name); ci.click();
        dd = await until(() => $$('.ant-dropdown').filter(shown).find(x => x.innerText.includes('手動填寫') && $$('.select-drop-item', x).length), 5000);
        r = dd ? pick($$('.select-drop-item', dd), name) : {};
      }
      if (r.hit) { r.hit.click(); await sleep(800); if (r.fuzzy) warn.push(`⚠ 社區：官網寫「${name}」，591 選了最接近的「${nm(r.hit)}」，請確認。`); }
      else { closeDrop(); warn.push(`⚠ 社區：591 的建議清單找不到「${name}」，請手動選擇或按「找不到社區？手動填寫」。`); }
    } else if (cRow && noComm) {   // 透天、公寓等沒有社區：手動填寫「無」
      const ci = $('input', cRow);
      ci.click(); ci.focus(); setv(ci, '無'); ci.click();
      const link = await until(() => $$('a').find(x => x.textContent.includes('手動填寫') && shown(x)), 4000);
      if (link) { link.click(); await sleep(600); setv($('input', cRow), '無'); }
      else { closeDrop(); warn.push('⚠ 社區：請按「找不到社區？手動填寫」並填「無」。'); }
    } else warn.push('⚠ 社區：官網沒填社區，請自己填（沒有社區可填「無」）。');

    // 4. 格局：官網「2房2廳2衛」
    const lm = String(s.layout || '').match(/(\d+)\s*房(?:\D*?(\d+)\s*廳)?(?:\D*?(\d+)\s*衛)?/);
    const lay = $$(T, $('[data-position=layout]') || document.createElement('i'));
    if (lm && lay.length) { setv(lay[0], lm[1]); setv(lay[1], lm[2] || 0); setv(lay[2], lm[3] || 0); }
    else if (lay.length) warn.push('⚠ 格局沒有填到，請手動填寫。');   // 店面等沒有格局欄就不提醒

    // 5. 建築完工時間：先用屋齡推算（民國年／月），提醒用 591 謄本匯入校正
    const age = parseFloat(s.age);
    const aRow = $('[data-position=age]');
    if (isFinite(age) && aRow) {
      const now = new Date(); const t = now.getFullYear() + now.getMonth() / 12 - age;
      const y = Math.floor(t), m = Math.min(12, Math.max(1, Math.round((t - y) * 12) + 1));
      await choose(aRow, '成屋');
      const ai = $$(T, aRow); setv(ai[0], y - 1911); setv(ai[1], m);
      warn.push(`⚠ 完工時間是依屋齡 ${age} 年推算的（民國 ${y - 1911} 年 ${m} 月），有空請填好門牌後按「匯入地址資訊」或「獲取」用謄本校正。`);
    } else warn.push('⚠ 讀不到屋齡，建築完工時間請手動填寫或用「匯入地址資訊」帶入。');

    // 6. 朝向：官網「座東南朝西北」→ 591「坐東南朝西北」
    const facing = String(s.facing || '').replace(/^座/, '坐');
    if (facing && !await antPick($('[data-position=direction] .ant-select'), facing)) warn.push(`⚠ 朝向「${facing}」沒有選到，請手動選擇。`);

    // 7. 坪數
    const parking = String(s.parking || '').trim();
    const hasPark = !!parking && !/^(無|沒有|-|—)/.test(parking);
    const ha = $('[data-position=house_area]');
    setv(ha && $(T, ha), num(s.areaTotal));
    await choose(ha, /含車位/.test(s.areaTotal || '') && !/不含車位/.test(s.areaTotal || '') ? '含車位面積' : '不含車位面積');
    setv($(T, rowBy('主建物') || document.createElement('i')), s.areaMain);
    setv($(T, rowBy('附屬建物') || document.createElement('i')), s.areaSub);
    setv($(T, rowBy('共有部分') || document.createElement('i')), s.areaShare);
    const land = $$('.ant-form-item').find(f => f.querySelector('select.native-select'));
    if (land && s.areaLand) {
      const ns = land.querySelector('select.native-select');
      ns.value = /透天|別墅/.test(s.type || '') ? '1' : '2'; ns.dispatchEvent(new Event('change', { bubbles: true }));
      setv($(T, land), s.areaLand);
    }

    // 8. 售價（萬元）與含車位
    const pr = $('[data-position=price]');
    if (!setv(pr && $(T, pr), num(s.price))) warn.push('⚠ 售價沒有填到，請手動填寫。');
    await choose(pr, hasPark ? '含車位價格' : '不含車位價格');

    // 9. 管理費
    const fee = rowBy('管理費'), feeN = num(s.fee);
    if (fee && feeN) { await choose(fee, '有'); await sleep(300); setv($(T, fee), feeN); }

    // 10. 生活機能（官網「近學校」「近公園」等標籤）
    const lifeRow = rowBy('生活機能');
    const map = { '近學校': '近學校', '近公園': '近公園綠地', '近公園綠地': '近公園綠地', '近醫療機構': '近醫療機構', '近醫院': '近醫療機構', '近傳統市場': '近傳統市場', '近市場': '近傳統市場', '近便利商店': '近便利商店', '近超商': '近便利商店', '近百貨公司': '近百貨公司', '近夜市': '近夜市' };
    for (const t of s.life || []) if (map[t]) { await choose(lifeRow, map[t]); await sleep(150); }

    // 11. 廣告標題（6～30 字）
    const hd = $('input[name=header]');
    const title = String(s.title || '').slice(0, 30);
    if (title.length >= 6) setv(hd, title); else warn.push('⚠ 廣告標題需 6～30 字，請手動填寫。');

    // 12. 特色描述：官網吸睛特色原文 ＋ 同仁聯絡資料 ＋ 團隊固定結尾
    const p = d.profile || {};
    const contact = [p.name && `聯絡人：${p.name}`, p.phone && `電話：${p.phone}`, p.line && `LINE：${p.line}`, p.lic && `營業員證號：${p.lic}`].filter(Boolean).join('｜');
    const text = [
      s.feature || '',
      '',
      contact,
      '',
      '台灣房屋澄果團隊  - 專營高雄美術館/農十六/瑞豐巨蛋 商耕團隊 - 買房賣房專業推薦',
      '✦ 美術青海特許加盟店 ✦',
      '｜服務專線 | 07-9766977',
      '｜門市地址 | 高雄市鼓山區青海路416號',
      '｜經 紀 業｜澄果資產有限公司',
      '｜經 紀 人｜邱秀琴(109)屏縣字第000147',
      '---------------------------------------------------------------------------',
      '澄果團隊長期深耕高雄美術館特區、農十六與瑞豐巨蛋生活圈，持續提供區域房價分析、市場趨勢、熱門社區介紹、',
      '',
      '首購族購屋建議及換屋規劃服務，協助買賣雙方掌握最新房市資訊。'
    ].join('\n').replace(/^\n+/, '');
    const ed = $('.ProseMirror');
    if (ed) {
      if (!ed.innerText.includes('美術青海特許加盟店')) {
        ed.focus();
        const sel = window.getSelection(); sel.selectAllChildren(ed); sel.collapseToEnd();
        document.execCommand('insertText', false, text);
      }
      await sleep(400);
      const left = +((document.body.innerText.match(/還剩\s*(-?\d+)\s*字數/) || [])[1]);
      if (isFinite(left) && left < 0) warn.push('⚠ 特色描述超過 591 字數上限，請刪減。');
    } else warn.push('⚠ 找不到特色描述編輯器，請手動貼上說明。');

    // 13. 照片：官網照片全部上傳（591 上限 30 張）
    const pics = (d.photos || []).slice(0, 30);
    const fileIn = $$('[data-position=pictures] input[type=file]').find(i => i.multiple) || $('[data-position=pictures] input[type=file]');
    if (pics.length && fileIn) {
      const dt = new DataTransfer();
      for (let i = 0; i < pics.length; i++) {
        const blob = await (await fetch(pics[i])).blob();
        dt.items.add(new File([blob], `photo${String(i + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }));
      }
      fileIn.files = dt.files; fileIn.dispatchEvent(new Event('change', { bubbles: true }));
      await until(() => $$('[data-position=pictures] img').length >= pics.length, 60000, 800);
    } else if (!pics.length) warn.push('⚠ 沒有官網照片可上傳，請手動上傳。');
    const upCount = $$('[data-position=pictures] img').length;

    // 14. 委託書由同仁選；服務費預設收取
    warn.push('⚠ 委託書請自己選「有簽訂」或「有簽訂專任約」；裝潢程度也請自己選。');
    const fee2 = $$('label.ant-radio-wrapper').find(l => l.innerText.trim() === '收取服務費');
    if (fee2 && !/wrapper-checked/.test(fee2.className)) (fee2.querySelector('input') || fee2).click();

    window.scrollTo(0, 0);
    banner('ok', '已填好 ✔ 請檢查、補上紅框的門牌號，再自己按最下方「保存資料，下一步」', [
      `物件：${s.title}（照片 ${upCount} 張）`,
      '下一步會選刊登方案與付款，請自己確認。',
      ...warn
    ]);
    return { ok: true, photos: upCount, warnings: warn };
  } catch (e) {
    banner('err', '自動填寫沒有完成', [e.message || String(e), '可以繼續手動填寫，已填好的欄位會保留。', ...warn]);
    return { ok: false, error: e.message || String(e), warnings: warn };
  }
}
