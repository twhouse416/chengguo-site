// 樂屋網「刊登出售」自動填寫（在 member.rakuya.com.tw/sell/post/add 頁面的主程式環境執行）
// 流程：快速搬家貼官網網址 → 匯入（著作權確認代按「是」）→ 補預設欄位 → 說明結尾加聯絡資料 → 顯示提示。
// 不會按「上架」或「庫存」——上架會扣刊登額度，一律由同仁自己確認後按。
async function rakuyaFill(d) {
  const warn = [];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const jq = window.jQuery;
  const until = async (fn, ms = 20000, step = 300) => { const t = Date.now(); while (Date.now() - t < ms) { try { const v = fn(); if (v) return v; } catch (e) {} await sleep(step); } return null; };
  const fire = el => { if (!el) return; if (jq) jq(el).trigger('input').trigger('change'); else ['input', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true }))); };
  const setVal = (el, v) => { if (!el) return false; el.value = v; fire(el); return true; };
  const tick = (el, on = true) => { if (el && el.checked !== on) el.click(); };
  const visible = el => !!(el && el.offsetParent !== null);

  function banner(kind, title, lines) {
    let b = document.getElementById('cg-banner');
    if (!b) { b = document.createElement('div'); b.id = 'cg-banner'; document.body.appendChild(b); }
    const bg = kind === 'ok' ? '#18794e' : kind === 'err' ? '#b42318' : '#151513';
    b.style.cssText = `position:fixed;left:0;right:0;top:0;z-index:2147483647;background:${bg};color:#fff;font:15px/1.6 "Microsoft JhengHei","Noto Sans TC",sans-serif;padding:10px 14px;box-shadow:0 2px 8px rgba(0,0,0,.3)`;
    b.innerHTML = '';
    const h = document.createElement('div'); h.style.fontWeight = '700'; h.textContent = '澄果上架｜' + title; b.appendChild(h);
    for (const l of lines || []) { const p = document.createElement('div'); p.textContent = l; if (/^⚠/.test(l)) { p.style.cssText = 'background:#fff6cc;color:#151513;border-radius:3px;padding:2px 8px;margin-top:4px'; } b.appendChild(p); }
    const x = document.createElement('button'); x.textContent = '關閉提示'; x.style.cssText = 'margin-top:6px;font:inherit;font-size:13px;padding:2px 10px;border:0;border-radius:3px;cursor:pointer';
    x.onclick = () => b.remove(); b.appendChild(x);
  }

  try {
    banner('run', '正在自動填寫樂屋網…', ['請先不要操作這個頁面，約 10～20 秒。']);

    // 1. 快速搬家：貼網址 → 匯入
    const box = await until(() => $('#wholeUrl'));
    const imp = $('#wholeItemCopy');
    if (!box || !imp) throw new Error('找不到樂屋網的「快速搬家」欄位，可能是樂屋網改版，請通知管理者。');
    setVal(box, d.url);
    imp.click();

    // 2. 著作權確認：代按「是，匯入照片文案」
    const ok = await until(() => { const b = $('#crawlAll'); return visible(b) && b; }, 15000);
    if (!ok) throw new Error('按了「匯入」但沒有出現著作權確認視窗。請確認網址是台灣房屋官網物件頁，或稍後再試。');
    ok.click();

    // 3. 等匯入完成（物件名稱有值）
    const done = await until(() => ($('[name=hname]') || {}).value, 25000);
    if (!done) throw new Error('樂屋網沒有匯入資料。可能是官網物件剛上架（樂屋網讀的是前一天的資料），請明天再試或手動填寫。');
    await sleep(2000);

    // 4. 法定用途：依官網「用途」欄對應；認不出來的先選住家用並提醒
    const raw = String(d.site.use || '').trim();
    let useName = '住家用', sure = true;
    if (/住商/.test(raw)) useName = '住商用';
    else if (/店面|店鋪|店舖/.test(raw)) useName = '店鋪';
    else if (/辦公|商辦|事務所/.test(raw)) useName = '商業用';
    else if (!/住宅|住家/.test(raw)) sure = false;
    const use = $('#selectPropertyUsecode');
    if (use) { const o = [...use.options].find(o => o.text.trim() === useName); if (o) setVal(use, o.value); }
    if (!sure) warn.push(`⚠ 法定用途：官網寫「${raw || '（空白）'}」，認不出來，先選「住家用」，請依謄本確認。`);

    // 5. 房屋分類：屋齡 3 年以內新屋，超過 3 年中古屋
    const ageRaw = ($('[name=findate]') || {}).value || d.site.age || '';
    const age = parseFloat(ageRaw);
    const ageType = isFinite(age) && age <= 3 ? 'N' : 'O';
    tick($(`input[name=agetype][value=${ageType}]`));
    if (!isFinite(age)) warn.push('⚠ 讀不到屋齡，房屋分類先選「中古屋」，請確認。');

    // 6. 單價：由系統計算
    tick($('[name=is_calc_single_price]'));

    // 7. 管理方式與管理費
    const mg = $('[name=manage]');
    if (mg && (mg.value === '1' || !mg.value)) setVal(mg, '2');   // 無 → 管理員(警衛)
    const fee = $('[name=securityfee]');
    if (fee && !fee.value.trim() && d.site.fee) setVal(fee, String(d.site.fee).replace(/\s+/g, ''));

    // 8. 車位：官網有車位就改「有車位」、勾總價含車位、補車位描述
    const pk = String(d.site.parking || '').trim();
    if (pk && !/^(無|沒有|-|—)/.test(pk)) {   // 「無車位」「無」都視為沒有車位
      tick($('input[name=parkings][value="4"]'));
      await sleep(300);
      tick($('[name=is_price_including_parkings]'));
      const g = $('[name=garage]');
      if (g && !g.value.trim()) setVal(g, pk.slice(0, 15));
    }

    // 9. 社區：依官網社區名比對樂屋網選單
    const name = String(d.site.community || '').trim();
    const cm = $('#community');
    const yes = $('input[name=is_community][value="1"]'), no = $('input[name=is_community][value="0"]');
    const norm = s => String(s).replace(/[\s　]/g, '').replace(/[（(].*?[)）]/g, '').replace(/[Ａ-Ｚａ-ｚ０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 65248)).replace(/(社區|大樓|大廈|華廈)$/,'').toLowerCase();
    const building = /大樓|華廈|大廈|套房|電梯/.test(String(d.site.type || ''));
    if (!name && building && cm) {
      // 官網社區欄空白的大樓：拿標題比對樂屋網選單（取最長的相符名稱），比對到也一律提醒確認；比對不到就留空
      tick(yes);
      await until(() => cm.options.length > 1, 8000);
      if (!cm.value) {
        const T = norm(d.site.title || '');
        let best = null;
        for (const o of [...cm.options].filter(o => o.value)) { const n = norm(o.text); if (n.length >= 2 && T.includes(n) && (!best || n.length > norm(best.text).length)) best = o; }
        if (best) { cm.value = best.value; fire(cm); warn.push(`⚠ 社區：官網沒填社區，依標題選了「${best.text.trim()}」，請確認是否正確。`); }
        else warn.push('⚠ 社區：官網沒填社區，標題也比對不到，請自己在「社區大樓」選單選擇（或改選「非社區大樓/建案」）。');
      }
    } else if (!name) {
      tick(no);
    } else if (cm) {
      tick(yes);
      await until(() => cm.options.length > 1, 8000);
      const opts = [...cm.options].filter(o => o.value);
      let hit = opts.find(o => o.text.trim() === name);
      let fuzzy = false;
      if (!hit) { const n = norm(name); hit = opts.find(o => norm(o.text) === n); if (!hit && n.length >= 3) hit = opts.find(o => { const t = norm(o.text); return t.length >= 3 && (t.includes(n) || n.includes(t)); }); fuzzy = !!hit; }
      if (hit) {
        cm.value = hit.value; fire(cm);
        if (fuzzy) warn.push(`⚠ 社區：官網寫「${name}」，樂屋網沒有完全相同的名稱，已選最接近的「${hit.text.trim()}」，請確認。`);
      } else {
        const nw = $('#community_new'), send = $('#sendCommunityNew');
        if (nw && send) { setVal(nw, name); send.click(); warn.push(`⚠ 社區：樂屋網選單找不到「${name}」，已填入並「送出審核」。`); }
        else warn.push(`⚠ 社區：樂屋網選單找不到「${name}」，請手動處理。`);
      }
    }

    // 10. 說明：官網原文 ＋ 同仁聯絡資料 ＋ 團隊固定結尾
    const MARK = '✦ 美術青海特許加盟店 ✦';
    const p = d.profile || {};
    const contact = [p.name && `聯絡人：${p.name}`, p.phone && `電話：${p.phone}`, p.line && `LINE：${p.line}`, p.lic && `營業員證號：${p.lic}`].filter(Boolean).join('｜');
    const tail = [
      '',
      contact,
      '',
      '台灣房屋澄果團隊  - 專營高雄美術館/農十六/瑞豐巨蛋 商耕團隊 - 買房賣房專業推薦',
      MARK,
      '｜服務專線 | 07-9766977',
      '｜門市地址 | 高雄市鼓山區青海路416號',
      '｜經 紀 業｜澄果資產有限公司',
      '｜經 紀 人｜邱秀琴(109)屏縣字第000147',
      '---------------------------------------------------------------------------',
      '澄果團隊長期深耕高雄美術館特區、農十六與瑞豐巨蛋生活圈，持續提供區域房價分析、市場趨勢、熱門社區介紹、',
      '',
      '首購族購屋建議及換屋規劃服務，協助買賣雙方掌握最新房市資訊。'
    ];
    const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const ed = jq && jq('#remark');
    if (ed && ed.summernote) {
      let html = ed.summernote('code') || '';
      if (!html.includes(MARK)) {
        html += tail.map(l => '<p>' + (l ? esc(l) : '<br>') + '</p>').join('');
        ed.summernote('code', html);
        ed.val(html).trigger('change');
        const ne = $('.note-editable'); if (ne) ne.dispatchEvent(new Event('keyup', { bubbles: true }));
      }
      await sleep(300);
      const cnt = ($$('*').find(e => /已輸入字數/.test(e.textContent) && e.textContent.length < 60) || {}).textContent || '';
      const left = +(cnt.match(/還剩\s*(-?\d+)/) || [])[1];
      if (isFinite(left) && left < 0) warn.push(`⚠ 說明超過樂屋網字數上限（${cnt.trim()}），請刪減官網原文。`);
    } else warn.push('⚠ 找不到說明編輯器，結尾的聯絡資料沒有加上，請手動貼上。');

    // 11. 檢查照片與必填
    // 每張已帶入的照片下方都有一顆「設為格局圖」按鈕，用它來數照片張數
    const tiles = $$('a,button,span').filter(e => e.textContent.trim() === '設為格局圖').length;
    const photos = tiles || new Set($$('img').map(i => i.src).filter(s => /img\.twhg\.com\.tw/i.test(s))).size;
    if (!photos) warn.push('⚠ 沒有帶入照片，請手動上傳。');
    if (!($('[name=addr_road]') || {}).value) warn.push('⚠ 地址路名是空的，請補上。');
    if (!($('[name=listprice]') || {}).value) warn.push('⚠ 總價是空的，請補上。');
    if (d.site.price && ($('[name=listprice]') || {}).value && String(parseFloat($('[name=listprice]').value)) !== String(parseFloat(d.site.price)))
      warn.push(`⚠ 總價與官網不同（樂屋網 ${$('[name=listprice]').value} 萬／官網 ${d.site.price} 萬）。樂屋網讀的是前一天的資料，請以官網為準修改。`);

    window.scrollTo(0, 0);
    banner('ok', '已填好 ✔ 請檢查後，自己按右下角「上架」', [
      `物件：${done}（${photos} 張照片）`,
      '上架會扣一筆刊登額度；照片上有台灣房屋浮水印，若樂屋網要求移除請改用物件資料夾照片。',
      ...warn
    ]);
    return { ok: true, title: done, warnings: warn };
  } catch (e) {
    banner('err', '自動填寫沒有完成', [e.message || String(e), '可以改用手動：快速搬家貼官網網址 → 匯入，再照平常方式補欄位。', ...warn]);
    return { ok: false, error: e.message || String(e), warnings: warn };
  }
}
